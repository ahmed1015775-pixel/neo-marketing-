# NEO Market v9.2 Release Checklist

## Code
- `npm run check`
- `npm test`
- `npm run release-check`
- `npm audit --omit=dev`
- Generate and commit `package-lock.json`; use `npm ci` in CI/production.

## Database staging
- Apply migrations on a fresh PostgreSQL database.
- Apply migrations on a copy of the current database.
- Confirm migration 009 preserves inventory reconciliation.
- Run inventory reconciliation before and after manual stock adjustments.
- Verify backup + restore.

## Customer flow
- Staging catalog loads from `/api/products`.
- Add/remove/quantity changes respect stock.
- Mixed currencies are blocked client-side and server-side.
- Successful Stripe checkout returns to a verified order status screen.
- Cancelled/failed payment remains retryable until reservation expiry.
- Expired checkout releases inventory exactly once.
- Concurrent checkout on last unit allows only one buyer to reserve it.

## Merchant flow
- Admin can create/edit/activate products.
- Admin inventory adjustments never allow negative stock and always create a ledger entry.
- Admin can inspect order details.
- Admin can update fulfillment state and tracking number.
- Supplier leads can move through the configured lifecycle.

## Stripe test mode
- Successful checkout.
- Declined payment then retry and success.
- Webhook replay/idempotency.
- Expired checkout.
- Amount/currency tampering rejection.
- Refund event handling.

## Deployment
- `DATABASE_SSL=true`.
- Strong `ADMIN_TOKEN` kept out of source control.
- HTTPS `PUBLIC_BASE_URL`.
- Correct `TRUST_PROXY` topology.
- Stripe webhook endpoint + secret configured.
- Health and readiness checks pass after deploy.
- Monitor error rate, DB connections, webhook delivery, reservations and inventory reconciliation.


## Current gate status
- Commerce mode: **STAGING / TEST ONLY**. Live Stripe keys are rejected unless `COMMERCE_MODE=live`.
- Shipping address + phone collection: enabled through Stripe Checkout and persisted on completed orders.
- Partial/full refund amount tracking: enabled.
- Reproducible dependency build: **BLOCKED until an authentic `package-lock.json` is generated with network/package registry access**. Do not fabricate the lockfile.
- Integration/E2E tests against real PostgreSQL + Stripe Test Mode: required before Live.
