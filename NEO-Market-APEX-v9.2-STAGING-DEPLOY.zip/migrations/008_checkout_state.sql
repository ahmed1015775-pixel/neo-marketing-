-- Scalable checkout state machine. External Stripe calls happen outside DB locks.
ALTER TABLE orders ADD COLUMN IF NOT EXISTS checkout_state TEXT NOT NULL DEFAULT 'idle';
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_checkout_state_check;
ALTER TABLE orders ADD CONSTRAINT orders_checkout_state_check CHECK (checkout_state IN ('idle','creating','ready'));
CREATE INDEX IF NOT EXISTS idx_orders_checkout_state ON orders(checkout_state,last_checkout_attempt_at) WHERE checkout_state='creating';
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM orders WHERE checkout_state='creating' AND last_checkout_attempt_at > NOW()) THEN
    RAISE EXCEPTION 'Migration preflight failed: checkout creation timestamps are in the future';
  END IF;
END $$;
