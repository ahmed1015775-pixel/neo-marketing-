ALTER TABLE orders ADD COLUMN IF NOT EXISTS customer_access_token_hash CHAR(64);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS fulfillment_status TEXT NOT NULL DEFAULT 'unfulfilled';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS tracking_number TEXT NOT NULL DEFAULT '';
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_fulfillment_status_check;
ALTER TABLE orders ADD CONSTRAINT orders_fulfillment_status_check CHECK (fulfillment_status IN ('unfulfilled','processing','shipped','delivered','cancelled'));
CREATE INDEX IF NOT EXISTS idx_orders_fulfillment ON orders(fulfillment_status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_customer_access ON orders(customer_access_token_hash) WHERE customer_access_token_hash IS NOT NULL;
UPDATE products p SET inventory_opening_stock = p.stock - COALESCE((SELECT SUM(l.quantity_delta) FROM inventory_ledger l WHERE l.product_id=p.id),0) WHERE inventory_opening_stock=0 AND EXISTS (SELECT 1 FROM inventory_ledger l WHERE l.product_id=p.id);
UPDATE products p SET inventory_opening_stock = p.stock WHERE inventory_opening_stock=0 AND NOT EXISTS (SELECT 1 FROM inventory_ledger l WHERE l.product_id=p.id);
