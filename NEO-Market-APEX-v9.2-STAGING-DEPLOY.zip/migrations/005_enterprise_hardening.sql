DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM products WHERE currency !~ '^[A-Z]{3}$') THEN RAISE EXCEPTION 'Migration preflight failed: products contain invalid currency codes'; END IF;
  IF EXISTS (SELECT 1 FROM orders WHERE discount_cents > subtotal_cents OR total_cents <> subtotal_cents-discount_cents) THEN RAISE EXCEPTION 'Migration preflight failed: orders contain inconsistent totals'; END IF;
END $$;

-- Enterprise hardening: shared rate limiting, session controls, cursors, and operational indexes.
CREATE TABLE IF NOT EXISTS rate_limit_buckets (
  bucket_key TEXT NOT NULL,
  window_start TIMESTAMPTZ NOT NULL,
  hit_count INTEGER NOT NULL DEFAULT 0 CHECK (hit_count >= 0),
  PRIMARY KEY (bucket_key, window_start)
);
CREATE INDEX IF NOT EXISTS idx_rate_limit_window ON rate_limit_buckets(window_start);

ALTER TABLE admin_sessions ADD COLUMN IF NOT EXISTS last_rotated_at TIMESTAMPTZ NOT NULL DEFAULT NOW();
ALTER TABLE admin_sessions ADD COLUMN IF NOT EXISTS absolute_expires_at TIMESTAMPTZ;
UPDATE admin_sessions SET absolute_expires_at = COALESCE(absolute_expires_at, expires_at) WHERE absolute_expires_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_admin_sessions_rotation ON admin_sessions(last_seen_at, last_rotated_at);

ALTER TABLE orders ADD COLUMN IF NOT EXISTS checkout_attempts INTEGER NOT NULL DEFAULT 0 CHECK (checkout_attempts >= 0);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS last_checkout_attempt_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_orders_cursor ON orders(created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_products_cursor ON products(active, id DESC);
CREATE INDEX IF NOT EXISTS idx_supplier_leads_cursor ON supplier_leads(created_at DESC, id DESC);

CREATE TABLE IF NOT EXISTS inventory_reconciliation_runs (
  id UUID PRIMARY KEY,
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  finished_at TIMESTAMPTZ,
  mismatch_count INTEGER NOT NULL DEFAULT 0,
  details JSONB NOT NULL DEFAULT '[]'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_inventory_reconciliation_runs_time ON inventory_reconciliation_runs(started_at DESC);

CREATE TABLE IF NOT EXISTS admin_actions (
  id UUID PRIMARY KEY,
  session_id UUID REFERENCES admin_sessions(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  ip INET,
  request_id UUID,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_admin_actions_time ON admin_actions(created_at DESC);

ALTER TABLE products ADD CONSTRAINT products_currency_check CHECK (currency ~ '^[A-Z]{3}$');
ALTER TABLE orders ADD CONSTRAINT orders_currency_check CHECK (currency ~ '^[A-Z]{3}$');
ALTER TABLE orders ADD COLUMN IF NOT EXISTS idempotency_owner_hash CHAR(64);
CREATE INDEX IF NOT EXISTS idx_orders_idempotency_owner ON orders(idempotency_key,idempotency_owner_hash);
ALTER TABLE products ADD COLUMN IF NOT EXISTS inventory_opening_stock INTEGER;
UPDATE products p SET inventory_opening_stock = p.stock - COALESCE((SELECT SUM(quantity_delta) FROM inventory_ledger l WHERE l.product_id=p.id),0) WHERE inventory_opening_stock IS NULL;
ALTER TABLE products ALTER COLUMN inventory_opening_stock SET DEFAULT 0;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM products WHERE inventory_opening_stock < 0) THEN RAISE EXCEPTION 'Migration preflight failed: inventory opening stock would be negative'; END IF;
END $$;

ALTER TABLE products ALTER COLUMN inventory_opening_stock SET NOT NULL;
ALTER TABLE products ADD CONSTRAINT products_opening_stock_check CHECK (inventory_opening_stock >= 0);
CREATE INDEX IF NOT EXISTS idx_products_inventory_reconcile ON products(id,stock,inventory_opening_stock);
