CREATE TABLE IF NOT EXISTS security_state (
  id SMALLINT PRIMARY KEY CHECK (id = 1),
  locked_down BOOLEAN NOT NULL DEFAULT FALSE,
  locked_at TIMESTAMPTZ,
  reason TEXT,
  maintenance BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO security_state(id) VALUES (1) ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS security_events (
  id UUID PRIMARY KEY,
  event_type TEXT NOT NULL,
  ip INET,
  request_id UUID,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_security_events_type_time ON security_events(event_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_security_events_ip_time ON security_events(ip, created_at DESC);

CREATE TABLE IF NOT EXISTS inventory_reservations (
  id UUID PRIMARY KEY,
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id BIGINT NOT NULL REFERENCES products(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  status TEXT NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved','consumed','released')),
  expires_at TIMESTAMPTZ NOT NULL,
  released_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(order_id, product_id)
);
CREATE INDEX IF NOT EXISTS idx_inventory_reservations_expiry ON inventory_reservations(status, expires_at);
CREATE INDEX IF NOT EXISTS idx_inventory_reservations_order ON inventory_reservations(order_id, status);


CREATE TABLE IF NOT EXISTS inventory_ledger (
  id BIGSERIAL PRIMARY KEY,
  product_id BIGINT NOT NULL REFERENCES products(id),
  order_id UUID REFERENCES orders(id) ON DELETE SET NULL,
  quantity_delta INTEGER NOT NULL CHECK (quantity_delta <> 0),
  reason TEXT NOT NULL CHECK (reason IN ('reservation','release','sale','manual_adjustment')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_inventory_ledger_product_time ON inventory_ledger(product_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_inventory_ledger_order ON inventory_ledger(order_id, created_at DESC);

ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_checkout_url TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS checkout_expires_at TIMESTAMPTZ;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS failure_reason TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS version INTEGER NOT NULL DEFAULT 1;
CREATE INDEX IF NOT EXISTS idx_orders_payment_session ON orders(payment_session_id);
CREATE INDEX IF NOT EXISTS idx_orders_customer_created ON orders(customer_email, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_checkout_expiry ON orders(status, checkout_expires_at);

CREATE UNIQUE INDEX IF NOT EXISTS uq_order_items_order_product ON order_items(order_id, product_id);
CREATE INDEX IF NOT EXISTS idx_products_active_category ON products(active, category, id);
CREATE INDEX IF NOT EXISTS idx_products_active_stock ON products(active, stock) WHERE active = TRUE;
CREATE INDEX IF NOT EXISTS idx_supplier_leads_status_created ON supplier_leads(status, created_at DESC);

ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check;
ALTER TABLE orders ADD CONSTRAINT orders_status_check CHECK (status IN ('pending_payment','paid','payment_expired','payment_failed','cancelled'));
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_payment_status_check;
ALTER TABLE orders ADD CONSTRAINT orders_payment_status_check CHECK (payment_status IN ('unpaid','paid','failed','refunded'));

CREATE OR REPLACE FUNCTION touch_updated_at() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_products_updated_at ON products;
CREATE TRIGGER trg_products_updated_at BEFORE UPDATE ON products FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
DROP TRIGGER IF EXISTS trg_orders_updated_at ON orders;
CREATE TRIGGER trg_orders_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
