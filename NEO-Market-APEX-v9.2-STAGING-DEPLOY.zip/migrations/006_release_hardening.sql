-- Final release hardening: CSRF state, stronger data invariants and operational retention.
ALTER TABLE admin_sessions ADD COLUMN IF NOT EXISTS csrf_token_hash CHAR(64);
CREATE INDEX IF NOT EXISTS idx_admin_sessions_csrf ON admin_sessions(csrf_token_hash) WHERE revoked_at IS NULL;

ALTER TABLE order_items DROP CONSTRAINT IF EXISTS order_items_line_total_check;
ALTER TABLE order_items ADD CONSTRAINT order_items_line_total_check CHECK (line_total_cents = unit_price_cents * quantity);

ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_email_check;
ALTER TABLE orders ADD CONSTRAINT orders_email_check CHECK (customer_email ~* '^[^[:space:]@]+@[^[:space:]@]+\\.[^[:space:]@]+$');

ALTER TABLE products DROP CONSTRAINT IF EXISTS products_slug_length_check;
ALTER TABLE products ADD CONSTRAINT products_slug_length_check CHECK (length(slug) BETWEEN 1 AND 160);
ALTER TABLE products DROP CONSTRAINT IF EXISTS products_name_length_check;
ALTER TABLE products ADD CONSTRAINT products_name_length_check CHECK (length(name) BETWEEN 1 AND 500);

CREATE INDEX IF NOT EXISTS idx_inventory_reservations_expired_batch ON inventory_reservations(expires_at, id) WHERE status='reserved';
CREATE INDEX IF NOT EXISTS idx_ip_denials_cleanup ON ip_denials(created_at);
CREATE INDEX IF NOT EXISTS idx_security_events_cleanup ON security_events(created_at);
CREATE INDEX IF NOT EXISTS idx_webhook_events_time ON webhook_events(processed_at DESC);

-- Prevent accidental negative inventory at the database boundary.
ALTER TABLE products DROP CONSTRAINT IF EXISTS products_stock_nonnegative_check;
ALTER TABLE products ADD CONSTRAINT products_stock_nonnegative_check CHECK (stock >= 0);
