-- Final integrity and operational guardrails. All checks are fail-fast so bad legacy data
-- cannot silently pass into the hardened schema.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM order_items GROUP BY order_id, product_id HAVING COUNT(*) > 1) THEN
    RAISE EXCEPTION 'Migration preflight failed: duplicate order_items for the same order/product';
  END IF;
  IF EXISTS (SELECT 1 FROM orders WHERE payment_session_id IS NULL AND payment_checkout_url IS NOT NULL) THEN
    RAISE EXCEPTION 'Migration preflight failed: order has checkout URL without payment session';
  END IF;
  IF EXISTS (SELECT 1 FROM orders WHERE payment_session_id IS NOT NULL AND payment_checkout_url IS NULL) THEN
    RAISE EXCEPTION 'Migration preflight failed: order has payment session without checkout URL';
  END IF;
  IF EXISTS (SELECT 1 FROM order_items WHERE line_total_cents <> unit_price_cents * quantity) THEN
    RAISE EXCEPTION 'Migration preflight failed: order item totals are inconsistent';
  END IF;
END $$;

ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_checkout_reference_consistency_check;
ALTER TABLE orders ADD CONSTRAINT orders_checkout_reference_consistency_check
  CHECK ((payment_session_id IS NULL AND payment_checkout_url IS NULL)
      OR (payment_session_id IS NOT NULL AND payment_checkout_url IS NOT NULL));

ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_checkout_attempts_check;
ALTER TABLE orders ADD CONSTRAINT orders_checkout_attempts_check CHECK (checkout_attempts BETWEEN 0 AND 100);

ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_payment_provider_check;
ALTER TABLE orders ADD CONSTRAINT orders_payment_provider_check CHECK (payment_provider IN ('stripe'));

ALTER TABLE admin_sessions DROP CONSTRAINT IF EXISTS admin_sessions_role_check;
ALTER TABLE admin_sessions ADD CONSTRAINT admin_sessions_role_check CHECK (role IN ('superadmin','admin','viewer'));

-- Legacy sessions without a CSRF hash must not remain usable.
CREATE INDEX IF NOT EXISTS idx_admin_sessions_missing_csrf ON admin_sessions(id) WHERE revoked_at IS NULL AND csrf_token_hash IS NULL;

-- Keep security/rate-limit tables bounded by inexpensive time-based cleanup scans.
CREATE INDEX IF NOT EXISTS idx_rate_limit_bucket_cleanup ON rate_limit_buckets(window_start,bucket_key);
CREATE INDEX IF NOT EXISTS idx_webhook_events_provider_type_time ON webhook_events(provider,event_type,processed_at DESC);
