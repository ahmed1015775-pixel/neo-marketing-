# NEO Market APEX v9.2 — Experience Expansion

- Added NEO Compare for up to three products.
- Added private order tracking UI using the existing access-token protected order endpoint.
- Added accessible labels to primary navigation actions.
- Improved mobile compare presentation.
- Kept commerce mode staging/test only; no live payments enabled by this release.
