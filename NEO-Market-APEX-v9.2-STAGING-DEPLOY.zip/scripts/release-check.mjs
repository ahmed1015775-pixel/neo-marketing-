import fs from 'node:fs/promises';
import path from 'node:path';
const root = path.resolve(new URL('..', import.meta.url).pathname);
const files = [];
async function walk(dir){for(const e of await fs.readdir(dir,{withFileTypes:true})){if(['node_modules','.git'].includes(e.name))continue;const p=path.join(dir,e.name);if(e.isDirectory())await walk(p);else files.push(p)}}
await walk(root);
const textFiles=files.filter(f=>/\.(mjs|js|html|sql|json|yaml|yml|env|md)$/.test(f));
const findings=[];
for(const f of textFiles){const s=await fs.readFile(f,'utf8');
  if(/(?:sk_live_|sk_test_|whsec_)[A-Za-z0-9_\-]+/.test(s) && !f.endsWith('.env.example')) findings.push(`${path.relative(root,f)}: possible Stripe secret`);
  if(/BEGIN (?:RSA|OPENSSH|EC|PRIVATE) KEY/.test(s)) findings.push(`${path.relative(root,f)}: private key material`);
  if(/\.(html)$/.test(f) && /(?:onclick|onkeydown|onkeyup|onload)\s*=/.test(s)) findings.push(`${path.relative(root,f)}: inline event handler`);
}
const pkg=JSON.parse(await fs.readFile(path.join(root,'package.json'),'utf8'));
if(!pkg.engines?.node || !pkg.dependencies?.express || !pkg.dependencies?.pg || !pkg.dependencies?.stripe) findings.push('package.json: required production dependencies/engine missing');
for (const migration of ['008_checkout_state.sql','009_customer_merchant_experience.sql','010_staging_shipping_refunds.sql']) if(!await fs.stat(path.join(root,'migrations',migration)).catch(()=>null)) findings.push(`missing required migration: ${migration}`);
if(pkg.version !== '9.2.0') findings.push('package.json: release version must be 9.2.0');
if(!await fs.stat(path.join(root,'package-lock.json')).catch(()=>null)) findings.push('package-lock.json: required for reproducible production builds');
if(Object.values(pkg.dependencies||{}).some(v=>/[~^*]/.test(v))) findings.push('package.json: production dependency ranges must be exact');
if(findings.length){console.error(findings.join('\n'));process.exit(1)}
console.log(`Release check PASS: ${textFiles.length} text files scanned, no inline handlers or embedded secrets detected.`);
