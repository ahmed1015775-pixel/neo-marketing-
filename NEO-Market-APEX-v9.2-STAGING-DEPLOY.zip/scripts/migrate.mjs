import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pool } from '../db/database.mjs';

const dir = path.resolve('./migrations');
const lock = await pool.connect();
try {
  await lock.query('SELECT pg_advisory_lock(4815162342)');
  await pool.query(`CREATE TABLE IF NOT EXISTS schema_migrations (filename TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  const files = (await fs.readdir(dir)).filter(f => f.endsWith('.sql')).sort();
  for (const file of files) {
    const exists = await pool.query('SELECT 1 FROM schema_migrations WHERE filename=$1', [file]);
    if (exists.rowCount) continue;
    const sql = await fs.readFile(path.join(dir, file), 'utf8');
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(sql);
      await client.query('INSERT INTO schema_migrations(filename) VALUES($1)', [file]);
      await client.query('COMMIT');
      console.log(`[DB] applied ${file}`);
    } catch (e) { await client.query('ROLLBACK').catch(() => {}); throw e; } finally { client.release(); }
  }
  console.log('[DB] migrations complete');
} finally {
  await lock.query('SELECT pg_advisory_unlock(4815162342)').catch(() => {});
  lock.release();
  await pool.end();
}
