import 'dotenv/config';
import { pool } from '../db/database.mjs';

const products = [
  ['neobook-pro-14','NeoBook Pro 14','Premium NEO laptop for coding and productivity.','Tech',109900,129900,'USD',25,'{"store":"TechZone","icon":"💻","tag":"Coding pick","rating":4.9}'],
  ['pixel-ultra-phone','Pixel Ultra Phone','High-end smartphone with a clean experience.','Mobile',79900,89900,'USD',40,'{"store":"TechZone","icon":"📱","tag":"New","rating":4.8}'],
  ['pulse-x-headset','Pulse X Headset','Wireless gaming headset with low-latency audio.','Gaming',12900,16900,'USD',60,'{"store":"NEO Gaming","icon":"🎧","tag":"Flash drop","rating":4.9}'],
  ['flux-mechanical-keyboard','Flux Mechanical Keyboard','Compact mechanical keyboard for gaming and work.','Gaming',8900,11900,'USD',80,'{"store":"NEO Gaming","icon":"⌨️","tag":"Best seller","rating":4.7}'],
  ['seoul-runner-sneakers','Seoul Runner Sneakers','Everyday performance sneakers.','Fashion',7400,9900,'USD',35,'{"store":"Seoul Fashion","icon":"👟","tag":"Trending","rating":4.8}'],
  ['aura-smart-lamp','Aura Smart Lamp','Ambient smart lighting for a modern desk or room.','Home',4900,6900,'USD',70,'{"store":"HomeLab","icon":"💡","tag":"Smart home","rating":4.6}'],
  ['airpods-neo','AirPods Neo','Compact wireless audio for daily use.','Mobile',15900,19900,'USD',50,'{"store":"Mobile Hub","icon":"🎵","tag":"Popular","rating":4.8}'],
  ['future-of-ai','The Future of AI','An accessible introduction to modern AI.','Books',2200,2900,'USD',100,'{"store":"ReadSpace","icon":"📘","tag":"Editor’s pick","rating":4.9}']
];
for (const p of products) {
  await pool.query(`INSERT INTO products(slug,name,description,category,price_cents,compare_at_cents,currency,stock,inventory_opening_stock,metadata)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$8,$9::jsonb)
    ON CONFLICT(slug) DO UPDATE SET name=EXCLUDED.name,description=EXCLUDED.description,category=EXCLUDED.category,price_cents=EXCLUDED.price_cents,compare_at_cents=EXCLUDED.compare_at_cents,currency=EXCLUDED.currency,metadata=EXCLUDED.metadata`, p);
}
await pool.end();
console.log(`[DB] seeded ${products.length} products`);
