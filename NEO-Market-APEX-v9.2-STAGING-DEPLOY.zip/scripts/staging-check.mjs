import fs from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve(new URL('..',import.meta.url).pathname);
const files=[];
async function walk(dir){for(const e of await fs.readdir(dir,{withFileTypes:true})){if(['node_modules','.git'].includes(e.name))continue;const p=path.join(dir,e.name);if(e.isDirectory())await walk(p);else files.push(p)}}
await walk(root);
const textFiles=files.filter(f=>/\.(mjs|js|html|sql|json|yaml|yml|env|md)$/.test(f));
const findings=[];
for(const f of textFiles){const s=await fs.readFile(f,'utf8');if(/(?:sk_live_|whsec_)[A-Za-z0-9_\-]+/.test(s) && !f.endsWith('.env.example'))findings.push(`${path.relative(root,f)}: possible live secret`);if(/BEGIN (?:RSA|OPENSSH|EC|PRIVATE) KEY/.test(s))findings.push(`${path.relative(root,f)}: private key material`);if(f.endsWith('.html')&&/(?:onclick|onkeydown|onkeyup|onload)\s*=/.test(s))findings.push(`${path.relative(root,f)}: inline event handler`)}
const pkg=JSON.parse(await fs.readFile(path.join(root,'package.json'),'utf8'));
if(pkg.version!=='9.2.0')findings.push('package.json: expected v9.2.0');
const docker=await fs.readFile(path.join(root,'Dockerfile'),'utf8');
if(!docker.includes('COPY package.json package-lock.json* ./'))findings.push('Dockerfile: staging must accept an optional package-lock.json');
if(!/npm ci --omit=dev/.test(docker) || !/npm install --omit=dev/.test(docker))findings.push('Dockerfile: must prefer npm ci with lockfile and fallback to npm install for staging');
if(!/HEALTHCHECK/.test(docker))findings.push('Dockerfile: healthcheck missing');
for(const m of ['009_customer_merchant_experience.sql','010_staging_shipping_refunds.sql'])if(!await fs.stat(path.join(root,'migrations',m)).catch(()=>null))findings.push(`missing required migration: ${m}`);
const env=await fs.readFile(path.join(root,'.env.example'),'utf8');
if(!/^COMMERCE_MODE=staging$/m.test(env))findings.push('.env.example: staging must be default');
if(findings.length){console.error(findings.join('\n'));process.exit(1)}
console.log(`Staging check PASS: ${textFiles.length} text files scanned; NEO v9.2 staging safeguards verified.`);
