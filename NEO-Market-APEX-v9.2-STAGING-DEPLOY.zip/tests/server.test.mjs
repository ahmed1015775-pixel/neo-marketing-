import test from 'node:test';
import assert from 'node:assert/strict';
import { SecurityEngine } from '../security/security-engine.mjs';

test('production node contract', () => assert.ok(Number(process.versions.node.split('.')[0]) >= 22));
test('security token policy is compatible with long secrets', () => {
  const s = new SecurityEngine({stateFile:'/tmp/neo-test-security.json'});
  assert.equal(s.state.autoLock, true);
  assert.equal(s.state.ipBan.enabled, true);
});
test('security engine bans repeated denied IPs', () => {
  const s = new SecurityEngine({stateFile:'/tmp/neo-test-security-2.json', ipBan:{threshold:2,windowMs:60000,durationMs:1000}});
  s.noteDeniedIp('203.0.113.10'); s.noteDeniedIp('203.0.113.10');
  assert.equal(s.isBanned('203.0.113.10'), true);
});
