import test from 'node:test';
import assert from 'node:assert/strict';
import { checkoutSchema, leadSchema } from '../security/validation.mjs';

test('checkout rejects invalid email and empty items',()=>assert.equal(checkoutSchema.safeParse({customerEmail:'bad',items:[]}).success,false));
test('checkout accepts bounded quantities',()=>assert.equal(checkoutSchema.safeParse({customerEmail:'buyer@example.com',items:[{productId:1,quantity:2}],idempotencyKey:'1234567890123456'}).success,true));
test('checkout rejects duplicate unknown fields',()=>assert.equal(checkoutSchema.safeParse({customerEmail:'buyer@example.com',items:[{productId:1,quantity:2}],evil:'x'}).success,false));
test('checkout caps quantity and item count',()=>assert.equal(checkoutSchema.safeParse({customerEmail:'buyer@example.com',items:[{productId:1,quantity:21}]}).success,false));
test('lead schema requires core fields',()=>assert.equal(leadSchema.safeParse({name:'Neo',phone:'123',country:'EG',type:'supplier'}).success,true));
test('lead schema rejects control characters',()=>assert.equal(leadSchema.safeParse({name:'Neo\u0000',phone:'123',country:'EG',type:'supplier'}).success,false));
