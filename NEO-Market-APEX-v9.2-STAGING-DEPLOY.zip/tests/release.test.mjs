import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(new URL('..',import.meta.url).pathname);

test('release has ordered migrations',()=>{const names=fs.readdirSync(path.join(root,'migrations')).filter(x=>x.endsWith('.sql')).sort();assert.deepEqual(names,['001_init.sql','002_stock_reservations.sql','003_hardening.sql','004_production_hardening.sql','005_enterprise_hardening.sql','006_release_hardening.sql','007_final_integrity.sql','008_checkout_state.sql','009_customer_merchant_experience.sql','010_staging_shipping_refunds.sql'])});
test('frontend has no inline event attributes',()=>{for(const f of ['public/index.html','public/admin.html']){const s=fs.readFileSync(path.join(root,f),'utf8');assert.equal(/(?:onclick|onkeydown|onkeyup|onload)\s*=/.test(s),false,`${f} contains inline handler`)}});
test('production checkout TTL respects Stripe minimum',()=>{const env=fs.readFileSync(path.join(root,'.env.example'),'utf8');const m=env.match(/^CHECKOUT_RESERVATION_MINUTES=(\d+)/m);assert.ok(m);assert.ok(Number(m[1])>=30)});
test('staging blocks live Stripe keys by default',()=>{const env=fs.readFileSync(path.join(root,'.env.example'),'utf8');assert.match(env,/^COMMERCE_MODE=staging$/m);assert.match(env,/^STRIPE_SECRET_KEY=sk_test_/m)});
test('Docker prefers lockfile and supports staging fallback',()=>{const s=fs.readFileSync(path.join(root,'Dockerfile'),'utf8');assert.match(s,/package-lock\.json\*/);assert.match(s,/npm ci --omit=dev/);assert.match(s,/npm install --omit=dev/);assert.match(s,/HEALTHCHECK/);});
test('release version is 9.2.0',()=>{const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));assert.equal(pkg.version,'9.2.0')});
test('server uses per-order advisory locking for checkout creation',()=>{const s=fs.readFileSync(path.join(root,'server.mjs'),'utf8');assert.ok(s.includes('pg_advisory_xact_lock(hashtextextended'))});
test('failed PaymentIntent events remain retryable',()=>{const s=fs.readFileSync(path.join(root,'server.mjs'),'utf8');assert.doesNotMatch(s,/UPDATE orders SET status='pending_payment',payment_status='unpaid',failure_reason=\$2/)});
test('refunds resolve by payment intent before early return',()=>{const s=fs.readFileSync(path.join(root,'server.mjs'),'utf8');const i=s.indexOf('let orderId = s.metadata?.order_id || s.client_reference_id || null;');const j=s.indexOf("if (!orderId) return true;",i);assert.ok(i>=0&&j>i);assert.ok(s.slice(i,j).includes('s.payment_intent'))});
test('fulfillment requires paid orders and blocks paid cancellation',()=>{const s=fs.readFileSync(path.join(root,'server.mjs'),'utf8');assert.match(s,/Only paid orders can enter fulfillment/);assert.match(s,/Refund the paid order before cancelling fulfillment/)});

test('Stripe Checkout collects delivery address and phone',()=>{const s=fs.readFileSync(path.join(root,'services/payment.mjs'),'utf8');assert.match(s,/shipping_address_collection/);assert.match(s,/phone_number_collection/)});
test('admin product creation is constrained to configured Stripe currency',()=>{const s=fs.readFileSync(path.join(root,'server.mjs'),'utf8');assert.match(s,/currency!==String\(process\.env\.STRIPE_CURRENCY\|\|'USD'\)\.toUpperCase\(\)/)});
test('completed checkout persists Stripe customer shipping details',()=>{const s=fs.readFileSync(path.join(root,'server.mjs'),'utf8');assert.match(s,/customer_phone=COALESCE/);assert.match(s,/shipping_address=CASE/)});


test('staging config endpoint is exposed',()=>{const s=fs.readFileSync(path.join(root,'server.mjs'),'utf8');assert.match(s,/app\.get\('\/api\/config'/);assert.match(s,/mode:COMMERCE_MODE/)});
test('public catalog supports server-side search',()=>{const s=fs.readFileSync(path.join(root,'server.mjs'),'utf8');assert.match(s,/req\.query\.q/);assert.match(s,/ILIKE/)});
test('admin mutations emit audit actions',()=>{const s=fs.readFileSync(path.join(root,'server.mjs'),'utf8');assert.match(s,/auditAdmin\(null,req,'product_create'/);assert.match(s,/auditAdmin\(null,req,'product_update'/);assert.match(s,/auditAdmin\(null,req,'inventory_adjust'/)});
test('staging UI identifies non-live environment',()=>{for(const f of ['public/index.html','public/admin.html']){const s=fs.readFileSync(path.join(root,f),'utf8');assert.match(s,/STAGING/);assert.match(s,/TEST/)}});

test('staging check script exists',()=>{assert.equal(fs.existsSync(path.join(root,'scripts/staging-check.mjs')),true);const p=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));assert.equal(p.scripts['staging-check'],'node scripts/staging-check.mjs')});