# NEO Market v9.2 — Deployment Hardening

- Fixed the Docker deployment blocker caused by requiring a missing `package-lock.json` during Staging builds.
- Docker now uses `npm ci` when a real lockfile exists and safely falls back to `npm install` for Staging.
- Added a container healthcheck against `/api/health`.
- Kept the Live release gate strict: a real generated `package-lock.json` is still required before Live commerce.
- Cleaned README release/version drift.
- Extended automated tests and staging checks for the deployment safeguards.

## Validation
- `npm run check` PASS
- `npm test` PASS
- `npm run staging-check` PASS
