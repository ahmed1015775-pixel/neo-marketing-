# NEO Market v7.2

## Pre-publication / staging hardening
- Added explicit `COMMERCE_MODE=staging|live`; live Stripe keys are blocked in staging.
- Added Stripe Checkout shipping address and phone collection for physical-goods fulfillment.
- Persisted customer phone and shipping address on orders.
- Added refund amount tracking for partial/full Stripe refunds.
- Fixed refund-event order lookup by `payment_intent` before early return.
- Hardened fulfillment transitions: processing/shipped/delivered require paid orders; paid orders must be refunded before cancellation.
- Allowed both `admin` and `superadmin` to perform merchant/product/fulfillment operations.
- Fixed concurrent admin authentication race by sharing one in-flight auth promise.
- Removed runtime-generated inline `onclick` handler that violated CSP.
- Strengthened release checks and migration coverage.
- Docker now requires `package-lock.json`; an authentic lockfile is intentionally still a release prerequisite.

## Verification
- Syntax checks and static tests are run before packaging.
- Full PostgreSQL/Stripe Test Mode integration tests remain required before Live.
