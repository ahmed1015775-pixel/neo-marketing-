# NEO Market v7.2 — Staging Test Gate

## Scope
This build is intentionally **STAGING / TEST ONLY**. Live Stripe keys are rejected unless `COMMERCE_MODE=live`.

## Automated checks completed
- JavaScript syntax checks: PASS
- Node test suite: PASS — 22/22
- Migration ordering: PASS — 001 through 010
- CSP inline-event static check: PASS
- Stripe Test Mode default configuration: PASS
- Fulfillment payment-state guard: PASS
- Refund lookup and partial/full refund accounting checks: PASS
- Shipping address + phone collection checks: PASS
- Product currency guard: PASS
- Checkout advisory-lock guard: PASS

## Required integration scenarios
These require a real PostgreSQL staging database and Stripe Test Mode credentials and therefore cannot be truthfully marked PASS from this isolated review environment.

1. Fresh database migration 001→010
2. Seed + inventory reconciliation
3. Successful Stripe Test checkout
4. Declined payment → retry → successful payment
5. Webhook replay/idempotency
6. Checkout expiry releases reserved inventory exactly once
7. Concurrent checkout for stock=1 never oversells
8. Client-side price/quantity/currency tampering is rejected server-side
9. Partial refund preserves paid state and records refunded amount
10. Full refund transitions payment to refunded
11. Fulfillment cannot advance an unpaid order
12. Paid order cannot be cancelled without refund
13. Shipping address + phone arrive from Stripe and are visible to admin/customer order status
14. Admin session concurrency across multiple requests/tabs
15. Backup + restore verification
16. Docker build/start/health/readiness verification

## Current blockers before Live
- Generate an authentic `package-lock.json` using npm registry access; do not fabricate it.
- Run the integration scenarios above against staging.
- Resolve any staging failures before changing `COMMERCE_MODE` to `live`.
