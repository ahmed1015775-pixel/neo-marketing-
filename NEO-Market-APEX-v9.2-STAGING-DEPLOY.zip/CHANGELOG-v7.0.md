# NEO Market v7.0 — Final Integrity Hardening

- Added a scalable checkout state machine (`idle` → `creating` → `ready`).
- Added transaction-scoped PostgreSQL advisory locking per order to prevent duplicate concurrent Stripe Checkout creation without holding a DB connection during the Stripe API call.
- Added stale checkout recovery after interrupted workers.
- Prevented retry attempts from extending the original inventory reservation/checkout expiration.
- Added Stripe expiration bounds validation (30 minutes to 24 hours).
- Prevented stale `payment_intent.payment_failed` events from incorrectly changing an order's payment state.
- Added stronger refund lookup through the PaymentIntent when charge metadata does not carry the order id.
- Added final database integrity preflight checks and consistency constraints.
- Added checkout-reference, role, payment-provider and retry-attempt constraints.
- Invalid API cursors now return a clear 400 instead of silently restarting pagination.
- Sensitive Admin operational actions require the `superadmin` role.
- Legacy Admin sessions without a CSRF hash are no longer accepted.
- Webhook errors return a generic public response while retaining internal request IDs/logging.
- Docker production install remains script-disabled and uses exact direct dependency versions; a real lockfile should be generated/committed by the project's networked CI before enabling `npm ci`.
