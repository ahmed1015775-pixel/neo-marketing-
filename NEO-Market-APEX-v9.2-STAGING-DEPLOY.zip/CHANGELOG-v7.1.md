# NEO Market v7.1 — Customer & Merchant Experience Hardening

## Customer-facing improvements
- Storefront now consumes the live PostgreSQL product catalog instead of a hard-coded browser catalog.
- Cart quantities respect live stock and remove stale products safely.
- Product cards show live price, discount calculation and stock warnings.
- Checkout validates same-currency carts before creating a payment session.
- Stripe success/cancel returns now verify the order server-side and show payment/fulfillment status.
- Customers receive a short-lived secret order-access token; the database stores only its SHA-256 hash.
- Removed misleading static commerce counters and fake activity/review claims from the storefront.

## Merchant-facing improvements
- Added live product catalog management from Admin.
- Added safe inventory adjustments with inventory-ledger entries.
- Added order list/detail and fulfillment workflow: unfulfilled → processing → shipped → delivered/cancelled.
- Added tracking-number storage on orders.
- Added supplier lead status workflow.
- Added audit-compatible operational controls without exposing payment secrets or raw card data.

## Data integrity
- Added migration 009 for customer order access and fulfillment state.
- Fixed inventory opening-stock reconciliation for legacy products.
- Seed script now initializes opening stock without resetting stock on repeat runs.

## Verification
- JavaScript syntax checks pass for modified server, payment, seed, storefront and admin files.
- Full dependency installation and integration tests still require a network-enabled/staging environment.
