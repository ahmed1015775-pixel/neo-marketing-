# NEO Market v4.0 — Production Hardening

- Database-backed admin sessions with HttpOnly/Secure/SameSite cookie.
- CSRF-style admin mutation header enforcement.
- Database-backed IP denials/bans for multi-instance consistency.
- Persistent auto-lock configuration and security incidents.
- Idempotent checkout retry can resume a pending order after a process crash.
- Stripe session/order identity is verified before marking payment paid.
- Inventory reservation ledger records stock reservation deltas.
- Stronger database constraints and payment-intent uniqueness.
- Added admin self-heal and auto-lock controls that the dashboard already exposes.
