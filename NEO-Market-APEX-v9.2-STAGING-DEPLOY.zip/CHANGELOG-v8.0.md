# NEO Market v9.0 — Apex Staging

## Focus
- Staging-first commerce controls with explicit non-live UI.
- Public runtime configuration endpoint for mode/currency.
- Server-side catalog search.
- Stronger admin audit coverage for product and inventory mutations.
- Production-quality product creation form replacing browser prompts.
- Admin catalog search.
- Existing checkout, inventory, shipping, refund and security hardening retained.

## Safety
This release remains STAGING/TEST by default. Live Stripe keys are blocked unless `COMMERCE_MODE=live`.
