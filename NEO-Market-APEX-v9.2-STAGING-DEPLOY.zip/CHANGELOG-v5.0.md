# NEO Market v5.0

## Production hardening
- PostgreSQL-backed shared rate limiting for multi-instance deployments.
- Rotating, idle-expiring admin sessions with absolute expiry.
- Cursor pagination for large product/order datasets.
- Batched inventory reservation cleanup using `SKIP LOCKED`.
- Inventory opening-stock baseline and reconciliation endpoint.
- Checkout idempotency bound to the customer email hash.
- Stripe coupon-backed reward discount so webhook amount validation matches the charged total.
- Stronger CSP: application scripts are external; inline event handlers remain supported for the legacy UI.
- Database transaction retry for serialization/deadlock errors.
- Migration preflight checks and operational indexes.
- Safer migration lock cleanup and admin diagnostics.
