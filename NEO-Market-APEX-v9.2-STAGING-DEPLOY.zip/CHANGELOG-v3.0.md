# NEO Market v3.0 Hardened

## Security
- Persistent PostgreSQL security/maintenance state.
- Persistent security event audit trail.
- Stronger admin secret requirement and optional IP allowlist.
- Constant-time admin token comparison and tighter admin rate limiting.
- Automatic lockdown retained with safer security-event handling.
- Production database TLS is explicitly checked.

## Commerce
- Duplicate cart lines are merged before reservation.
- Single-currency enforcement against `STRIPE_CURRENCY`.
- Transactional stock reservations with expiry.
- Stripe Checkout expiry synchronized with inventory reservation expiry.
- Inventory ledger records reservation/release movements.
- Stripe webhook amount/currency verification.
- Idempotent webhook processing retained.
- Idempotency race handling for concurrent checkout requests.
- Payment/refund status handling improved.

## Operations
- PostgreSQL connection pool tuned for higher concurrency.
- Query and statement timeouts added.
- Advisory lock added to migrations.
- Production container runs migrations before startup.
- Expired reservations are reconciled at startup and every minute.
- Operational state refreshes across multiple application instances.
- API responses use request IDs and no-store caching.
- Product listing supports bounded pagination/filtering.

## Validation
- Strict Zod objects reject unexpected fields.
- Control characters are rejected in supplier text fields.
- Checkout quantities, IDs and idempotency keys are bounded.
