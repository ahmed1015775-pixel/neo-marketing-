# NEO Market v6.0 — Final Hardening

- Stripe-compatible checkout TTL validation (30 minutes to 24 hours).
- Admin CSRF tokens persisted as hashes and rotated safely with admin sessions.
- Strict CSP disallows inline event handlers.
- Removed inline event handlers from public/admin HTML and dynamic storefront markup.
- Public API rate limiting no longer applies to Stripe webhooks, health, readiness, or admin routes.
- Stripe `payment_intent.payment_failed` remains retryable instead of permanently blocking checkout completion.
- Checkout now expires an orphaned Stripe session if persisting the session to PostgreSQL fails.
- Admin origin verification added for state-changing requests.
- Cursor pagination carries a stable `(created_at,id)` position for admin orders.
- Additional database invariants, cleanup indexes, and inventory constraints.
- Added release scanner for embedded secrets and inline event handlers.

- Render proxy trust configured explicitly for a single known proxy hop.
- Added release integrity tests.
