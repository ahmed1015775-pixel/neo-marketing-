import pg from 'pg';
const { Pool } = pg;

if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required.');
const isProd = process.env.NODE_ENV === 'production';
const poolMax = Number(process.env.DB_POOL_MAX || 20);
if (!Number.isInteger(poolMax) || poolMax < 2 || poolMax > 100) throw new Error('DB_POOL_MAX must be 2..100.');
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL, max: poolMax,
  ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: process.env.DATABASE_SSL_REJECT_UNAUTHORIZED !== 'false' } : undefined,
  idleTimeoutMillis: 30_000, connectionTimeoutMillis: 5_000,
  statement_timeout: Number(process.env.DB_STATEMENT_TIMEOUT_MS || 15_000),
  query_timeout: Number(process.env.DB_QUERY_TIMEOUT_MS || 15_000),
  application_name: process.env.DB_APPLICATION_NAME || 'neo-market'
});
pool.on('error', err => console.error('[DB POOL ERROR]', err.message));
if (isProd && process.env.DATABASE_SSL !== 'true') throw new Error('DATABASE_SSL=true is required in production.');
export async function query(text, params = []) { return pool.query(text, params); }
export async function withTransaction(fn, { isolation = 'READ COMMITTED', retries = 2 } = {}) {
  let attempt = 0;
  while (true) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(`SET LOCAL TRANSACTION ISOLATION LEVEL ${isolation}`);
      const result = await fn(client);
      await client.query('COMMIT');
      return result;
    } catch (e) {
      await client.query('ROLLBACK').catch(() => {});
      if (attempt < retries && (e?.code === '40001' || e?.code === '40P01')) { attempt += 1; continue; }
      throw e;
    } finally { client.release(); }
  }
}

export async function advisoryLock(key) { const c = await pool.connect(); await c.query('SELECT pg_advisory_lock(hashtextextended($1,0))', [String(key)]); return c; }
export async function ping() { await query('SELECT 1'); return true; }
export async function closeDb() { await pool.end(); }
