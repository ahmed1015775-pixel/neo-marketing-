import Stripe from 'stripe';
const provider=process.env.PAYMENT_PROVIDER||'stripe';
const commerceMode=String(process.env.COMMERCE_MODE||'staging').toLowerCase();
const allowedCountries=String(process.env.STRIPE_ALLOWED_COUNTRIES||'EG').split(',').map(x=>x.trim().toUpperCase()).filter(Boolean);
if (!allowedCountries.every(x=>/^[A-Z]{2}$/.test(x))) throw new Error('STRIPE_ALLOWED_COUNTRIES must contain ISO 3166-1 alpha-2 country codes.');
const stripe=provider==='stripe'&&process.env.STRIPE_SECRET_KEY?new Stripe(process.env.STRIPE_SECRET_KEY):null;
export function paymentReady(){return provider==='stripe'&&Boolean(stripe&&process.env.STRIPE_WEBHOOK_SECRET&&process.env.STRIPE_CURRENCY)}
export function livePaymentsBlocked(){return commerceMode!=='live';}
export function constructWebhookEvent(payload,signature){if(!stripe||!process.env.STRIPE_WEBHOOK_SECRET)throw new Error('Stripe webhook is not configured.');return stripe.webhooks.constructEvent(payload,signature,process.env.STRIPE_WEBHOOK_SECRET)}
export async function createCheckoutSession({orderId,email,items,currency='usd',discountCents=0,baseUrl,expiresAt,accessToken}){
  if(!stripe)throw new Error('Stripe is not configured.');
  if (commerceMode !== 'live' && /^sk_live_/i.test(String(process.env.STRIPE_SECRET_KEY||''))) throw new Error('Live Stripe keys are blocked while COMMERCE_MODE is not live.');
  if (commerceMode === 'live' && !/^sk_live_/i.test(String(process.env.STRIPE_SECRET_KEY||''))) throw new Error('Live mode requires a live Stripe secret key.');
  const cur=String(currency).toLowerCase(),base=new URL(baseUrl); const exp=Math.floor(new Date(expiresAt).getTime()/1000); if(!/^[a-z]{3}$/.test(cur)||!Number.isInteger(exp)||exp<=Math.floor(Date.now()/1000)+1800||exp>Math.floor(Date.now()/1000)+86400) throw new Error('Invalid Stripe Checkout expiration or currency.');
  const params={mode:'payment',customer_email:email,line_items:items.map(i=>({quantity:i.quantity,price_data:{currency:cur,product_data:{name:i.product_name},unit_amount:i.unit_price_cents}})),shipping_address_collection:{allowed_countries:allowedCountries},phone_number_collection:{enabled:true},success_url:new URL(`/?checkout=success&order=${encodeURIComponent(orderId)}&access=${encodeURIComponent(accessToken||'')}`,base).toString(),cancel_url:new URL(`/?checkout=cancelled&order=${encodeURIComponent(orderId)}&access=${encodeURIComponent(accessToken||'')}`,base).toString(),metadata:{order_id:orderId},client_reference_id:orderId,expires_at:exp,payment_intent_data:{metadata:{order_id:orderId}}};
  if(Number(discountCents)>0){
    const coupon=await stripe.coupons.create({duration:'once',amount_off:Number(discountCents),currency:cur,name:'NEO Reward'}, {idempotencyKey:`neo-coupon-${orderId}`});
    params.discounts=[{coupon:coupon.id}];
  }
  return stripe.checkout.sessions.create(params,{idempotencyKey:`neo-checkout-${orderId}`});
}
export async function expireCheckoutSession(sessionId){if(!stripe||!sessionId)return null;try{return await stripe.checkout.sessions.expire(sessionId)}catch(e){if(e?.code==='checkout_session_not_expired')return null;throw e}}
