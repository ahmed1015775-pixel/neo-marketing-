import OpenAI from 'openai';
const client = process.env.AI_PROVIDER === 'openai' && process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;
export function aiReady(){return Boolean(client);}
export async function recommend(query){ if(!client)return {configured:false,answer:'AI service is not configured yet.'}; const response=await client.responses.create({model:process.env.OPENAI_MODEL||'gpt-5-mini',input:`You are NEO Market assistant. Give concise, safe shopping guidance. User query: ${String(query).slice(0,1000)}`,max_output_tokens:Number(process.env.AI_MAX_OUTPUT_TOKENS||500)}); return {configured:true,answer:response.output_text||''}; }
