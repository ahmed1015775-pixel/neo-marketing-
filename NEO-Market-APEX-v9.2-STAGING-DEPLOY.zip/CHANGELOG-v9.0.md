# NEO Market v9.0 — APEX EXPERIENCE

## Highlights
- Premium customer experience refresh with search, sorting, responsive catalog tools, theme preference, recent discovery memory and keyboard accessibility.
- PWA shell with installable manifest and offline-safe static fallback.
- Staging-first commerce remains enforced; no Live payment activation was introduced.
- AI recommendations now receive a bounded snapshot of the active catalog and are instructed not to invent products, prices, stock or delivery promises.
- Product discovery is server-backed and remains server-authoritative for checkout and inventory.

## Safety
This release remains a staging candidate. Live Stripe keys are still forbidden unless `COMMERCE_MODE=live` is explicitly selected with a valid live secret.
