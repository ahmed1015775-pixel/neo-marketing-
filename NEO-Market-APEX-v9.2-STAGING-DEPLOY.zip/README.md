# NEO Market Production Ultimate v9.2

Production-hardened marketplace foundation with PostgreSQL, Stripe Checkout, signed/idempotent webhooks, transactional inventory reservations, persistent security state/audit logs, automatic reservation expiry, rate limiting, Docker and deployment checks.

## What was hardened
- Duplicate cart lines are aggregated before stock reservation.
- Orders enforce a single configured Stripe currency.
- Inventory reservations are transactional and have an explicit expiry lifecycle.
- Stripe Checkout expiry is aligned with the reservation TTL.
- Reservation releases are recorded in an inventory ledger.
- Stripe webhooks are signature-verified and idempotent.
- Security lockdown, maintenance and auto-lock configuration are persisted in PostgreSQL and shared across instances.
- Admin authentication exchanges the bootstrap secret for a short-lived HttpOnly/Secure/SameSite session stored in PostgreSQL; mutating admin requests require an anti-CSRF request header, with aggressive rate limiting and optional IP allowlisting.
- Security events, incidents, IP denials/bans and admin sessions are persisted in PostgreSQL.
- PostgreSQL uses pool limits, TLS checks, query/statement timeouts and an advisory migration lock.
- API responses are non-cacheable and include request IDs.
- Production startup automatically runs database migrations before the server.

## Quick start
1. Copy `.env.example` to `.env` and set real secrets. Never commit `.env`.
2. Run `npm install`.
3. Run `npm run check`.
4. Run `npm test`.
5. Run `npm start` (startup applies migrations automatically).
6. Use `npm run db:seed` only for demo/catalog environments.

## Production requirements
- Node 22+
- Managed PostgreSQL with TLS, automated backups, point-in-time recovery and monitoring
- HTTPS reverse proxy/CDN/WAF
- Stripe live secret and signed webhook secret
- `STRIPE_CURRENCY` must match the product catalog currency
- `ADMIN_TOKEN` should be at least 64 random characters; rotate it regularly
- Prefer setting `ADMIN_IP_ALLOWLIST` to trusted office/VPN egress IPs
- OpenAI key only if AI is enabled
- Stripe webhook endpoint: `/api/webhooks/stripe`

## Deployment notes
The container runs migrations before starting the API. The migration runner uses a PostgreSQL advisory lock so multiple instances do not migrate concurrently.

Do not use demo seed data or live payment keys until end-to-end checkout, webhook, refund, expiry and stock-reconciliation tests pass in the target environment.


## v9.2 final hardening notes

- Rate limits are shared through PostgreSQL and work across multiple application instances.
- Admin authentication uses rotating, idle-expiring database sessions.
- Product and order listings use cursor pagination for large datasets.
- Expired inventory reservations are processed in bounded batches with `SKIP LOCKED`.
- Inventory has an opening-stock baseline plus a ledger reconciliation check.
- Checkout idempotency keys are bound to a customer-email hash.
- Stripe reward discounts are represented by one-time coupons so charged totals match order totals.
- Application JavaScript is served as external files and CSP blocks inline event-handler attributes.
- Stripe payment failures remain retryable until a successful checkout completion event.
- Orphaned Stripe sessions are expired if PostgreSQL persistence fails after session creation.
- Admin state-changing requests use a database-backed CSRF token and same-origin verification.
- Release checks scan for embedded secrets and inline event handlers.
- Render proxy trust is explicitly configured for one platform proxy hop.
- Checkout TTL is constrained to Stripe-compatible 30 minutes–24 hours.

### Important release gate
The deployment environment must commit and use a generated `package-lock.json` after a networked dependency install, then pin the CI/deployment build to that lockfile. The current source intentionally does not ship a fabricated lockfile.


### Safe staging mode
Set `COMMERCE_MODE=staging` (the default in `.env.example` and Render config). Live Stripe secret keys are rejected in staging. Use Stripe Test Mode until the full integration test gate passes.
