import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import crypto from 'node:crypto';
import path from 'node:path';
import { SecurityEngine } from './security/security-engine.mjs';
import { checkoutSchema, leadSchema, parseBody, requireObjectBody } from './security/validation.mjs';
import { query, withTransaction, ping, closeDb } from './db/database.mjs';
import { paymentReady, constructWebhookEvent, createCheckoutSession, expireCheckoutSession } from './services/payment.mjs';
import { aiReady, recommend } from './services/ai.mjs';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const STATIC_DIR = path.resolve(process.env.STATIC_DIR || './public');
const BASE_URL = (process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '');
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const ADMIN_IP_ALLOWLIST = (process.env.ADMIN_IP_ALLOWLIST || '').split(',').map(x => x.trim()).filter(Boolean);
const COMMERCE_MODE = String(process.env.COMMERCE_MODE || 'staging').toLowerCase();
const CHECKOUT_TTL_MIN = Number(process.env.CHECKOUT_RESERVATION_MINUTES || 30);
const ADMIN_SESSION_TTL_HOURS = Number(process.env.ADMIN_SESSION_TTL_HOURS || 8);
const ADMIN_IDLE_MIN = Number(process.env.ADMIN_SESSION_IDLE_MINUTES || 30);
const ADMIN_ROTATE_MIN = Number(process.env.ADMIN_SESSION_ROTATE_MINUTES || 10);
const PUBLIC_RATE_LIMIT = Number(process.env.PUBLIC_RATE_LIMIT || 120);
const CHECKOUT_RATE_LIMIT = Number(process.env.CHECKOUT_RATE_LIMIT || 8);
const LEAD_RATE_LIMIT = Number(process.env.LEAD_RATE_LIMIT || 5);
const AI_RATE_LIMIT = Number(process.env.AI_RATE_LIMIT || 20);
const ADMIN_RATE_LIMIT = Number(process.env.ADMIN_RATE_LIMIT || 20);

if (!Number.isInteger(CHECKOUT_TTL_MIN) || CHECKOUT_TTL_MIN < 30 || CHECKOUT_TTL_MIN > 1440) throw new Error('CHECKOUT_RESERVATION_MINUTES must be 30..1440 for Stripe Checkout compatibility');
if (!Number.isInteger(ADMIN_SESSION_TTL_HOURS) || ADMIN_SESSION_TTL_HOURS < 1 || ADMIN_SESSION_TTL_HOURS > 24) throw new Error('ADMIN_SESSION_TTL_HOURS must be 1..24');
if (!Number.isInteger(ADMIN_IDLE_MIN) || ADMIN_IDLE_MIN < 5 || ADMIN_IDLE_MIN > 120) throw new Error('ADMIN_SESSION_IDLE_MINUTES must be 5..120');
if (!Number.isInteger(ADMIN_ROTATE_MIN) || ADMIN_ROTATE_MIN < 1 || ADMIN_ROTATE_MIN > 60) throw new Error('ADMIN_SESSION_ROTATE_MINUTES must be 1..60');
if (!['staging','live'].includes(COMMERCE_MODE)) throw new Error('COMMERCE_MODE must be staging or live.');
if (COMMERCE_MODE === 'staging' && /^sk_live_/i.test(String(process.env.STRIPE_SECRET_KEY || ''))) throw new Error('Live Stripe keys are forbidden in staging.');
if (COMMERCE_MODE === 'live' && !/^sk_live_/i.test(String(process.env.STRIPE_SECRET_KEY || ''))) throw new Error('Live commerce requires a live Stripe secret key.');
if (process.env.NODE_ENV === 'production') {
  if (ADMIN_TOKEN.length < 48) throw new Error('ADMIN_TOKEN must be at least 48 characters in production.');
  if (!BASE_URL.startsWith('https://')) throw new Error('PUBLIC_BASE_URL must be an HTTPS URL in production.');
  if (process.env.TRUST_PROXY === 'true' && !Number.isInteger(Number(process.env.TRUST_PROXY_HOPS))) throw new Error('TRUST_PROXY_HOPS must be an integer.');
}
if (process.env.TRUST_PROXY === 'true') app.set('trust proxy', Number(process.env.TRUST_PROXY_HOPS || 1));

const security = new SecurityEngine({
  autoLock: process.env.AUTO_LOCKDOWN !== 'false',
  thresholds: { deniedAdmin: process.env.LOCK_DENIED_ADMIN || 8, serverErrors: process.env.LOCK_SERVER_ERRORS || 15, windowMs: process.env.LOCK_WINDOW_MS || 60000 },
  ipBan: { enabled: process.env.IP_AUTO_BAN !== 'false', threshold: process.env.IP_DENIED_THRESHOLD || 6, windowMs: process.env.IP_DENIED_WINDOW_MS || 300000, durationMs: process.env.IP_BAN_DURATION_MS || 900000 },
  db: { query: (...a) => query(...a) }
});
let maintenance = false;
const paused = () => security.state.lockedDown || Boolean(security.state.maintenance);
const ADMIN_COOKIE = '__Host-neo_admin';
const hashToken = t => crypto.createHash('sha256').update(String(t)).digest('hex');
const tokenEq = (a, b) => { const x = Buffer.from(String(a || '')); const y = Buffer.from(String(b || '')); return x.length >= 48 && x.length === y.length && crypto.timingSafeEqual(x, y); };
const parseCookie = (header, name) => { try { for (const part of String(header || '').split(';')) { const [k, ...v] = part.trim().split('='); if (k === name) return decodeURIComponent(v.join('=')); } } catch {} return null; };
const encodeCursor = value => Buffer.from(JSON.stringify(value)).toString('base64url');
const decodeCursor = value => { try { const x = JSON.parse(Buffer.from(String(value), 'base64url').toString('utf8')); if (!x || typeof x !== 'object') return null; const id = Number(x.id); return Number.isSafeInteger(id) && id > 0 ? { id, createdAt: x.createdAt || null } : null; } catch { return null; } };
const safeJson = value => { try { return JSON.stringify(value); } catch { return '{}'; } };
const configuredCurrency = String(process.env.STRIPE_CURRENCY || 'USD').toUpperCase();
const stagingOnly = COMMERCE_MODE !== 'live';
async function auditAdmin(cOrDb, req, action, payload={}) { const runner = cOrDb?.query ? cOrDb : { query }; await runner.query('INSERT INTO admin_actions(id,session_id,action,ip,request_id,payload) VALUES($1,$2,$3,$4,$5,$6)', [crypto.randomUUID(), req.admin.id, action, req.ip, req.requestId, safeJson(payload)]); }

async function consumeRateLimit(key, limit, windowSeconds) {
  if (!Number.isInteger(limit) || limit < 1) return { allowed: true, remaining: 0, reset: 0 };
  const nowSec = Math.floor(Date.now() / 1000);
  const startSec = Math.floor(nowSec / windowSeconds) * windowSeconds;
  const r = await query(`INSERT INTO rate_limit_buckets(bucket_key,window_start,hit_count) VALUES($1,to_timestamp($2),1)
    ON CONFLICT(bucket_key,window_start) DO UPDATE SET hit_count=rate_limit_buckets.hit_count+1 RETURNING hit_count`, [key, startSec]);
  const count = Number(r.rows[0].hit_count);
  return { allowed: count <= limit, remaining: Math.max(0, limit - count), reset: startSec + windowSeconds };
}
function rateLimited(bucket, limit, windowSeconds = 60) {
  return async (req, res, next) => { try { const x = await consumeRateLimit(`${bucket}:${req.ip}`, limit, windowSeconds); res.setHeader('RateLimit-Limit', String(limit)); res.setHeader('RateLimit-Remaining', String(x.remaining)); res.setHeader('RateLimit-Reset', String(x.reset)); if (!x.allowed) return res.status(429).json({ message: 'Too many requests. Please try again later.', requestId: req.requestId }); next(); } catch (e) { next(e); } };
}

async function setAdminCookie(res, raw, maxAge) { res.cookie(ADMIN_COOKIE, raw, { httpOnly: true, secure: true, sameSite: 'strict', path: '/', maxAge }); }
async function adminSession(req, res) {
  const raw = parseCookie(req.get('cookie'), ADMIN_COOKIE); if (!raw) return null;
  const r = await query(`SELECT id,role,token_hash,csrf_token_hash,last_seen_at,expires_at,absolute_expires_at,last_rotated_at,created_at
    FROM admin_sessions WHERE token_hash=$1 AND revoked_at IS NULL AND expires_at>NOW()
      AND COALESCE(absolute_expires_at,expires_at)>NOW()
      AND csrf_token_hash IS NOT NULL AND last_seen_at>NOW()-($2::int*INTERVAL '1 minute')`, [hashToken(raw), ADMIN_IDLE_MIN]);
  if (!r.rowCount) return null;
  const s = r.rows[0];
  await query('UPDATE admin_sessions SET last_seen_at=NOW() WHERE id=$1 AND token_hash=$2 AND revoked_at IS NULL', [s.id, hashToken(raw)]);
  return { id: s.id, role: s.role, csrfHash: s.csrf_token_hash };
}

function tokenEqHash(raw, expectedHash) {
  const actual = hashToken(raw); const a = Buffer.from(actual); const b = Buffer.from(String(expectedHash || '')); return a.length === b.length && crypto.timingSafeEqual(a,b);
}


app.disable('x-powered-by'); app.disable('etag');
app.use(helmet({
  contentSecurityPolicy: { directives: {
    defaultSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"], scriptSrc: ["'self'"], scriptSrcAttr: ["'none'"],
    imgSrc: ["'self'", 'data:', 'https:'], connectSrc: ["'self'"], fontSrc: ["'self'", 'https:', 'data:'], objectSrc: ["'none'"],
    baseUri: ["'self'"], frameAncestors: ["'none'"], formAction: ["'self'"], upgradeInsecureRequests: []
  }}, crossOriginEmbedderPolicy: false, referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
}));
app.use((req, res, next) => { req.requestId = crypto.randomUUID(); res.setHeader('X-Request-ID', req.requestId); res.setHeader('Cache-Control', 'no-store'); next(); });

app.post('/api/webhooks/stripe', rateLimited('webhook', 300, 60), express.raw({ type: 'application/json', limit: '256kb' }), async (req, res, next) => {
  try {
    const event = constructWebhookEvent(req.body, req.get('stripe-signature'));
    const processed = await withTransaction(async c => {
      const ins = await c.query('INSERT INTO webhook_events(provider,event_id,event_type) VALUES($1,$2,$3) ON CONFLICT DO NOTHING RETURNING event_id', ['stripe', event.id, event.type]);
      if (!ins.rowCount) return false;
      const s = event.data.object;
      let orderId = s.metadata?.order_id || s.client_reference_id || null;
      if (!orderId && s.payment_intent) orderId = (await c.query('SELECT id FROM orders WHERE payment_intent_id=$1 FOR UPDATE', [s.payment_intent])).rows[0]?.id || null;
      if (!orderId) return true;
      const order = (await c.query('SELECT id,total_cents,currency,payment_status,payment_session_id,status,payment_intent_id,refunded_cents FROM orders WHERE id=$1 FOR UPDATE', [orderId])).rows[0];
      if (!order) throw Object.assign(new Error('Order not found for Stripe event'), { statusCode: 400 });
      if (event.type === 'checkout.session.completed') {
        if (order.payment_status === 'paid') return true;
        if (order.payment_session_id && order.payment_session_id !== s.id) throw Object.assign(new Error('Stripe session does not match order'), { statusCode: 400 });
        if (Number(s.amount_total) !== Number(order.total_cents) || String(s.currency || '').toUpperCase() !== String(order.currency || '').toUpperCase()) throw Object.assign(new Error('Stripe amount/currency does not match order'), { statusCode: 400 });
        await c.query("UPDATE orders SET status='paid',payment_status='paid',payment_session_id=COALESCE(payment_session_id,$2),payment_intent_id=$3,customer_phone=COALESCE(NULLIF($4,''),customer_phone),shipping_address=CASE WHEN $5::jsonb <> '{}'::jsonb THEN $5::jsonb ELSE shipping_address END,checkout_expires_at=NULL,failure_reason=NULL,updated_at=NOW() WHERE id=$1 AND payment_status='unpaid'", [orderId, s.id, s.payment_intent || null, String(s.customer_details?.phone || s.customer_details?.phone_number || '').slice(0,50), JSON.stringify(s.shipping_details?.address || s.customer_details?.address || {})]);
        await c.query("UPDATE inventory_reservations SET status='consumed',released_at=NULL WHERE order_id=$1 AND status='reserved'", [orderId]);
        await c.query("UPDATE order_items SET stock_reserved=false WHERE order_id=$1 AND stock_reserved=true", [orderId]);
      } else if (event.type === 'checkout.session.expired') {
        const rows = (await c.query("SELECT product_id,quantity FROM inventory_reservations WHERE order_id=$1 AND status='reserved' FOR UPDATE", [orderId])).rows;
        for (const it of rows) { await c.query('UPDATE products SET stock=stock+$1 WHERE id=$2', [it.quantity, it.product_id]); await c.query("INSERT INTO inventory_ledger(product_id,order_id,quantity_delta,reason) VALUES($1,$2,$3,'release')", [it.product_id, orderId, it.quantity]); }
        await c.query("UPDATE inventory_reservations SET status='released',released_at=NOW() WHERE order_id=$1 AND status='reserved'", [orderId]);
        await c.query("UPDATE order_items SET stock_reserved=false WHERE order_id=$1 AND stock_reserved=true", [orderId]);
        await c.query("UPDATE orders SET status='payment_expired',checkout_expires_at=NULL WHERE id=$1 AND payment_status='unpaid'", [orderId]);
      } else if (event.type === 'payment_intent.payment_failed') {
        // Do not transition the order on a failed PaymentIntent: an older failed attempt can arrive
        // after a newer checkout attempt. The order remains retryable until its reservation expires.
        await c.query("UPDATE orders SET failure_reason=$2,updated_at=NOW() WHERE id=$1 AND payment_status='unpaid'", [orderId, String(s.last_payment_error?.message || 'Payment failed').slice(0, 500)]);
      } else if (event.type === 'charge.refunded') {
        const refunded = Math.max(0, Number(s.amount_refunded || 0));
        const total = Number(order.total_cents);
        if (!Number.isSafeInteger(refunded) || refunded > total) throw Object.assign(new Error('Invalid Stripe refund amount'), { statusCode: 400 });
        if (refunded > Number(order.refunded_cents || 0)) {
          await c.query("UPDATE orders SET refunded_cents=$2,payment_status=CASE WHEN $2 >= total_cents THEN 'refunded' ELSE payment_status END,status=CASE WHEN $2 >= total_cents THEN 'cancelled' ELSE status END,updated_at=NOW() WHERE id=$1", [order.id, refunded]);
        }
      }
      return true;
    });
    res.json({ received: true, processed });
  } catch (e) { e.statusCode = 400; e.publicMessage = 'Webhook rejected.'; next(e); }
});
app.use(express.json({ limit: '64kb', strict: true, type: ['application/json', 'application/*+json'] }));
app.use(async (req, res, next) => { try { if (await security.isBanned(req.ip)) return res.status(403).json({ message: 'Request blocked.', requestId: req.requestId }); next(); } catch (e) { next(e); } });

app.get('/api/health', async (req, res) => { let db = 'down'; try { await ping(); db = 'ok'; } catch {} const status = db !== 'ok' ? 'degraded' : security.state.lockedDown ? 'locked_down' : maintenance ? 'maintenance' : 'ok'; res.status(db === 'ok' ? 200 : 503).json({ status, checkedAt: new Date().toISOString(), requestId: req.requestId, services: { api: { status: 'ok', note: 'HTTP service responding' }, database: { status: db, note: db === 'ok' ? 'PostgreSQL reachable' : 'PostgreSQL unavailable' }, payments: { status: paymentReady() ? 'ok' : 'warn', note: paymentReady() ? 'Stripe configuration present' : 'Stripe not configured' }, ai: { status: aiReady() ? 'ok' : 'warn', note: aiReady() ? 'AI gateway configured' : 'AI optional service not configured' } } }); });
app.get('/api/ready', async (req, res) => { try { await ping(); if (process.env.NODE_ENV === 'production' && !paymentReady()) throw Error('Payment provider not ready'); res.json({ ready: true, requestId: req.requestId }); } catch { res.status(503).json({ ready: false, message: 'Service not ready', requestId: req.requestId }); } });
app.use('/api', (req, res, next) => paused() && !req.path.startsWith('/admin') && !req.path.startsWith('/webhooks/') ? res.status(503).json({ message: 'Public traffic is temporarily paused.', requestId: req.requestId }) : next());
app.use('/api', (req, res, next) => (req.path.startsWith('/webhooks/') || req.path.startsWith('/admin') || req.path === '/health' || req.path === '/ready') ? next() : rateLimited('api', PUBLIC_RATE_LIMIT, 60)(req, res, next));

async function admin(req, res, next) {
  try {
    if (ADMIN_IP_ALLOWLIST.length && !ADMIN_IP_ALLOWLIST.includes(req.ip)) { await security.addEvent('admin_denied', { ip: req.ip, path: req.path, requestId: req.requestId, reason: 'ip_not_allowlisted' }); await security.noteDeniedIp(req.ip); return res.status(403).json({ message: 'Admin access blocked from this network.', requestId: req.requestId }); }
    const session = await adminSession(req, res);
    if (!session) { await security.addEvent('admin_denied', { ip: req.ip, path: req.path, requestId: req.requestId }); await security.noteDeniedIp(req.ip); return res.status(401).json({ message: 'Unauthorized', requestId: req.requestId }); }
    req.admin = session; if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS') { const origin = req.get('origin'); if (origin && BASE_URL && origin !== BASE_URL) return res.status(403).json({ message: 'Origin verification failed.', requestId: req.requestId }); const csrf = req.get('x-csrf-token'); if (!csrf || !tokenEqHash(csrf, session.csrfHash)) return res.status(403).json({ message: 'CSRF verification failed.', requestId: req.requestId }); } await security.addEvent('admin_access', { ip: req.ip, path: req.path, requestId: req.requestId, role: session.role }); next();
  } catch (e) { next(e); }
}
app.post('/api/admin/session', rateLimited('admin-login', ADMIN_RATE_LIMIT, 60), requireObjectBody, async (req, res, next) => {
  try {
    const token = String(req.body.token || '');
    if (!tokenEq(token, ADMIN_TOKEN)) { await security.addEvent('admin_denied', { ip: req.ip, path: req.path, requestId: req.requestId, reason: 'bad_token' }); await security.noteDeniedIp(req.ip); return res.status(401).json({ message: 'Unauthorized', requestId: req.requestId }); }
    const raw = crypto.randomBytes(32).toString('base64url'); const csrfRaw = crypto.randomBytes(32).toString('base64url'); const now = Date.now(); const absoluteMs = ADMIN_SESSION_TTL_HOURS * 3600000;
    const id = crypto.randomUUID();
    await query("INSERT INTO admin_sessions(id,token_hash,csrf_token_hash,role,ip,user_agent,expires_at,absolute_expires_at,last_rotated_at) VALUES($1,$2,$3,$4,$5,$6,NOW()+($7::int*INTERVAL '1 hour'),NOW()+($7::int*INTERVAL '1 hour'),NOW())", [id, hashToken(raw), hashToken(csrfRaw), process.env.ADMIN_ROLE || 'superadmin', req.ip, String(req.get('user-agent') || '').slice(0, 500), ADMIN_SESSION_TTL_HOURS]);
    await setAdminCookie(res, raw, absoluteMs); await security.addEvent('admin_session_created', { ip: req.ip, requestId: req.requestId }); res.json({ ok: true, expiresInHours: ADMIN_SESSION_TTL_HOURS, csrfToken: csrfRaw, requestId: req.requestId });
  } catch (e) { next(e); }
});
app.get('/api/admin/session', rateLimited('admin-session', ADMIN_RATE_LIMIT, 60), admin, async (req, res, next) => {
  try {
    const raw = parseCookie(req.get('cookie'), ADMIN_COOKIE);
    if (!raw) return res.status(401).json({ message: 'Unauthorized', requestId: req.requestId });
    const nextRaw = crypto.randomBytes(32).toString('base64url');
    const csrfRaw = crypto.randomBytes(32).toString('base64url');
    const r = await query(`UPDATE admin_sessions SET token_hash=$2,csrf_token_hash=$3,last_rotated_at=NOW(),last_seen_at=NOW(),
      expires_at=LEAST(NOW()+($4::int*INTERVAL '1 hour'),COALESCE(absolute_expires_at,NOW()+($4::int*INTERVAL '1 hour')))
      WHERE id=$1 AND token_hash=$5 AND revoked_at IS NULL AND expires_at>NOW() AND COALESCE(absolute_expires_at,expires_at)>NOW()
      RETURNING expires_at`, [req.admin.id, hashToken(nextRaw), hashToken(csrfRaw), ADMIN_SESSION_TTL_HOURS, hashToken(raw)]);
    if (!r.rowCount) return res.status(401).json({ message: 'Session changed; please retry.', requestId: req.requestId });
    await setAdminCookie(res, nextRaw, Math.max(0, new Date(r.rows[0].expires_at).getTime()-Date.now()));
    res.json({ authenticated: true, role: req.admin.role, csrfToken: csrfRaw, requestId: req.requestId });
  } catch(e){ next(e); }
});
app.delete('/api/admin/session', rateLimited('admin-logout', ADMIN_RATE_LIMIT, 60), admin, async (req, res, next) => { try { const raw = parseCookie(req.get('cookie'), ADMIN_COOKIE); if (raw) await query('UPDATE admin_sessions SET revoked_at=NOW() WHERE token_hash=$1', [hashToken(raw)]); res.clearCookie(ADMIN_COOKIE, { httpOnly: true, secure: true, sameSite: 'strict', path: '/' }); res.json({ ok: true, requestId: req.requestId }); } catch (e) { next(e); } });
app.use('/api/admin', rateLimited('admin', ADMIN_RATE_LIMIT, 60), admin);
function requireRole(...roles) { return (req, res, next) => roles.includes(req.admin?.role) ? next() : res.status(403).json({ message: 'Insufficient admin privileges.', requestId: req.requestId }); }


app.get('/api/config', (req,res) => res.json({mode:COMMERCE_MODE,staging:stagingOnly,currency:configuredCurrency,checkoutEnabled:paymentReady(),requestId:req.requestId}));

app.get('/api/products', async (req, res, next) => { try { const category = typeof req.query.category === 'string' ? req.query.category.trim().slice(0, 60) : null; const q = typeof req.query.q === 'string' ? req.query.q.trim().slice(0, 120) : null; const limit = Math.min(Math.max(Number(req.query.limit) || 50, 1), 100); const rawCursor = req.query.cursor; const cursor = decodeCursor(rawCursor); if (rawCursor && !cursor) return res.status(400).json({ message: 'Invalid cursor.', requestId: req.requestId }); const params = [category, q, limit + 1]; const where = ['active=true', '($1::text IS NULL OR category=$1)', '($2::text IS NULL OR name ILIKE '%' || $2 || '%' OR description ILIKE '%' || $2 || '%')']; if (cursor) { params.push(cursor); where.push(`id < $${params.length}`); } const r = await query(`SELECT id,slug,name,description,category,price_cents,compare_at_cents,currency,stock,metadata FROM products WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT $3`, params); const hasMore = r.rows.length > limit; const items = hasMore ? r.rows.slice(0, limit) : r.rows; res.json({ items, limit, nextCursor: hasMore ? encodeCursor({ id: items.at(-1).id, createdAt: items.at(-1).created_at }) : null }); } catch (e) { next(e); } });
app.post('/api/suppliers/leads', rateLimited('lead', LEAD_RATE_LIMIT, 900), requireObjectBody, async (req, res, next) => { const p = parseBody(leadSchema, req.body); if (!p.ok) return res.status(400).json({ message: 'Invalid lead data.', issues: p.issues, requestId: req.requestId }); try { const id = crypto.randomUUID(); await query('INSERT INTO supplier_leads(id,name,phone,country,type,contact_window,note) VALUES($1,$2,$3,$4,$5,$6,$7)', [id, p.data.name, p.data.phone, p.data.country, p.data.type, p.data.contactWindow, p.data.note]); res.status(201).json({ ok: true, id, requestId: req.requestId }); } catch (e) { next(e); } });

async function releaseOrderReservations(c, orderId, reason='release') {
  const rows = (await c.query("SELECT product_id,quantity FROM inventory_reservations WHERE order_id=$1 AND status='reserved' FOR UPDATE", [orderId])).rows;
  for (const it of rows) { await c.query('UPDATE products SET stock=stock+$1 WHERE id=$2', [it.quantity, it.product_id]); await c.query("INSERT INTO inventory_ledger(product_id,order_id,quantity_delta,reason) VALUES($1,$2,$3,$4)", [it.product_id, orderId, it.quantity, reason]); }
  if (rows.length) { await c.query("UPDATE inventory_reservations SET status='released',released_at=NOW() WHERE order_id=$1 AND status='reserved'", [orderId]); await c.query("UPDATE order_items SET stock_reserved=false WHERE order_id=$1 AND stock_reserved=true", [orderId]); }
  return rows.length;
}

app.post('/api/orders/checkout-session', rateLimited('checkout', CHECKOUT_RATE_LIMIT, 900), requireObjectBody, async (req, res, next) => {
  const p = parseBody(checkoutSchema, req.body); if (!p.ok) return res.status(400).json({ message: 'Invalid checkout data.', issues: p.issues, requestId: req.requestId });
  if (!paymentReady()) return res.status(503).json({ message: 'Payments are temporarily unavailable.', requestId: req.requestId });
  const idem = p.data.idempotencyKey || crypto.randomUUID();
  const ownerHash = hashToken(p.data.customerEmail.trim().toLowerCase());
  try {
    let prepared = await withTransaction(async c => {
      const old = await c.query('SELECT id,payment_session_id,payment_checkout_url,status,payment_status,checkout_expires_at,customer_email,currency,idempotency_owner_hash FROM orders WHERE idempotency_key=$1 FOR UPDATE', [idem]);
      if (old.rowCount) {
        const o = old.rows[0];
        if (o.idempotency_owner_hash && o.idempotency_owner_hash !== ownerHash) throw Object.assign(Error('Idempotency key is already associated with another customer'), { statusCode: 409 });
        if (!o.idempotency_owner_hash) await c.query('UPDATE orders SET idempotency_owner_hash=$2 WHERE id=$1', [o.id, ownerHash]);
        if (o.payment_status !== 'unpaid' || !['pending_payment','payment_failed'].includes(o.status)) return { existing: true, terminal: true, ...o };
        if (o.checkout_expires_at && new Date(o.checkout_expires_at) <= new Date()) { await releaseOrderReservations(c, o.id); await c.query("UPDATE orders SET status='payment_expired',checkout_expires_at=NULL WHERE id=$1 AND payment_status='unpaid'", [o.id]); return { existing: true, terminal: true, ...o, status: 'payment_expired' }; }
        return { existing: true, id: o.id, session: o.payment_session_id, url: o.payment_checkout_url, status: o.status, email: o.customer_email, currency: o.currency };
      }
      const grouped = new Map(); for (const it of p.data.items) grouped.set(it.productId, (grouped.get(it.productId) || 0) + it.quantity);
      const ids = [...grouped.keys()]; const rows = (await c.query('SELECT id,name,price_cents,currency,stock FROM products WHERE id=ANY($1::bigint[]) AND active=true FOR UPDATE', [ids])).rows;
      const map = new Map(rows.map(x => [Number(x.id), x])); if (map.size !== ids.length) throw Object.assign(Error('One or more products are unavailable'), { statusCode: 409 });
      const currencies = new Set(rows.map(x => x.currency.toUpperCase())); if (currencies.size !== 1) throw Object.assign(Error('All products in one order must use the same currency'), { statusCode: 409 });
      const orderCurrency = rows[0].currency.toUpperCase(); const configuredCurrency = String(process.env.STRIPE_CURRENCY || 'USD').toUpperCase(); if (orderCurrency !== configuredCurrency) throw Object.assign(Error(`Unsupported checkout currency: ${orderCurrency}`), { statusCode: 409 });
      let subtotal = 0; const items = [];
      for (const [productId, quantity] of grouped) { const x = map.get(productId); if (x.stock < quantity) throw Object.assign(Error(`Insufficient stock for ${x.name}`), { statusCode: 409 }); const line = x.price_cents * quantity; if (!Number.isSafeInteger(line) || subtotal + line > 2147483647) throw Object.assign(Error('Order total is too large'), { statusCode: 400 }); subtotal += line; items.push({ product_id: x.id, product_name: x.name, unit_price_cents: x.price_cents, quantity, line_total_cents: line, currency: x.currency }); }
      const discount = subtotal >= 50000 ? 5000 : 0, total = subtotal - discount, id = crypto.randomUUID();
      const accessToken = crypto.randomBytes(32).toString('base64url');
      await c.query('INSERT INTO orders(id,customer_email,currency,subtotal_cents,discount_cents,total_cents,idempotency_key,idempotency_owner_hash,customer_access_token_hash,checkout_expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,NOW()+($10::int*INTERVAL \'1 minute\'))', [id, p.data.customerEmail, orderCurrency, subtotal, discount, total, idem, ownerHash, hashToken(accessToken), CHECKOUT_TTL_MIN]);
      for (const x of items) { const upd = await c.query('UPDATE products SET stock=stock-$1 WHERE id=$2 AND stock >= $1', [x.quantity, x.product_id]); if (!upd.rowCount) throw Object.assign(Error(`Insufficient stock for ${x.product_name}`), { statusCode: 409 }); await c.query("INSERT INTO inventory_ledger(product_id,order_id,quantity_delta,reason) VALUES($1,$2,$3,'reservation')", [x.product_id, id, -x.quantity]); await c.query('INSERT INTO order_items(order_id,product_id,product_name,unit_price_cents,quantity,line_total_cents) VALUES($1,$2,$3,$4,$5,$6)', [id, x.product_id, x.product_name, x.unit_price_cents, x.quantity, x.line_total_cents]); await c.query('INSERT INTO inventory_reservations(id,order_id,product_id,quantity,expires_at) VALUES($1,$2,$3,$4,NOW()+($5::int*INTERVAL \'1 minute\'))', [crypto.randomUUID(), id, x.product_id, x.quantity, CHECKOUT_TTL_MIN]); }
      return { existing: false, id, items, currency: orderCurrency, email: p.data.customerEmail, discountCents: discount, accessToken };
    });
    if (prepared.terminal) return res.status(409).json({ message: 'This order can no longer be resumed.', orderId: prepared.id, status: prepared.status, requestId: req.requestId });
    if (prepared.existing && prepared.session) return res.status(200).json({ ok: true, orderId: prepared.id, url: prepared.url, status: prepared.status, retry: true, expiresAt: prepared.checkout_expires_at, requestId: req.requestId });
    if (prepared.existing) {
      const current = (await query("SELECT o.id,o.customer_email,o.currency,o.status,o.payment_status,o.checkout_expires_at,COALESCE(json_agg(json_build_object('product_id',oi.product_id,'product_name',oi.product_name,'unit_price_cents',oi.unit_price_cents,'quantity',oi.quantity,'line_total_cents',oi.line_total_cents)) FILTER (WHERE oi.id IS NOT NULL),'[]') items FROM orders o LEFT JOIN order_items oi ON oi.order_id=o.id WHERE o.id=$1 GROUP BY o.id", [prepared.id])).rows[0];
      if (!current || current.payment_status !== 'unpaid' || !['pending_payment','payment_failed'].includes(current.status)) return res.status(409).json({ message: 'This order can no longer be resumed.', orderId: prepared.id, status: current?.status, requestId: req.requestId });
      const totals=(await query('SELECT subtotal_cents,discount_cents,total_cents FROM orders WHERE id=$1',[prepared.id])).rows[0]; prepared = { ...prepared, existing: false, email: current.customer_email, currency: current.currency, items: current.items.map(x => ({ ...x, product_id: Number(x.product_id) })), discountCents: Number(totals?.discount_cents||0) };
    }
    const checkoutResult = await withTransaction(async c => {
      const lock = await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [`checkout:${prepared.id}`]);
      const current = (await c.query('SELECT id,payment_session_id,payment_checkout_url,status,payment_status,checkout_expires_at,checkout_attempts,checkout_state FROM orders WHERE id=$1 FOR UPDATE', [prepared.id])).rows[0];
      if (!current) throw Object.assign(Error('Order no longer exists'), { statusCode: 409 });
      if (current.payment_status !== 'unpaid' || !['pending_payment','payment_failed'].includes(current.status)) return { terminal: true, status: current.status, orderId: current.id };
      if (current.payment_session_id && current.payment_checkout_url) return { existing: true, orderId: current.id, url: current.payment_checkout_url, status: current.status, expiresAt: current.checkout_expires_at };
      if (Number(current.checkout_attempts || 0) >= 20) throw Object.assign(Error('Checkout retry limit reached. Please start a new order.'), { statusCode: 429 });
      if (current.checkout_state === 'creating') return { retryAfter: true, orderId: current.id };
      await c.query("UPDATE orders SET checkout_state='creating',checkout_attempts=checkout_attempts+1,last_checkout_attempt_at=NOW() WHERE id=$1 AND payment_status='unpaid'", [prepared.id]);
      const expiresAt = current.checkout_expires_at ? new Date(current.checkout_expires_at).toISOString() : new Date(Date.now() + CHECKOUT_TTL_MIN * 60000).toISOString();
      if (new Date(expiresAt).getTime() <= Date.now() + 30000) {
        await c.query("UPDATE orders SET checkout_state='idle',status='payment_expired',checkout_expires_at=NULL,updated_at=NOW() WHERE id=$1 AND payment_status='unpaid'", [prepared.id]);
        await releaseOrderReservations(c, prepared.id);
        return { terminal: true, status: 'payment_expired', orderId: current.id };
      }
      return { create: true, orderId: current.id, email: prepared.email, items: prepared.items, currency: prepared.currency, discountCents: prepared.discountCents || 0, expiresAt, accessToken: prepared.accessToken || null };
    });
    if (checkoutResult.retryAfter) return res.status(409).json({ message: 'Checkout is already being prepared. Please retry shortly.', orderId: checkoutResult.orderId, retryAfterMs: 1000, requestId: req.requestId });
    if (checkoutResult.terminal) return res.status(409).json({ message: 'This order can no longer be resumed.', orderId: checkoutResult.orderId, status: checkoutResult.status, requestId: req.requestId });
    if (checkoutResult.existing) return res.status(200).json({ ok: true, orderId: checkoutResult.orderId, url: checkoutResult.url, status: checkoutResult.status, retry: true, expiresAt: checkoutResult.expiresAt, requestId: req.requestId });
    let session;
    try {
      session = await createCheckoutSession({ orderId: checkoutResult.orderId, email: checkoutResult.email, items: checkoutResult.items, currency: checkoutResult.currency, discountCents: checkoutResult.discountCents, baseUrl: BASE_URL, expiresAt: checkoutResult.expiresAt, accessToken: checkoutResult.accessToken });
    } catch (e) {
      await query("UPDATE orders SET checkout_state='idle',failure_reason=$2,status='pending_payment',payment_status='unpaid',updated_at=NOW() WHERE id=$1 AND payment_status='unpaid' AND payment_session_id IS NULL", [checkoutResult.orderId, String(e.message || 'Stripe error').slice(0, 500)]);
      throw e;
    }
    try {
      const saved = await query("UPDATE orders SET payment_session_id=$2,payment_checkout_url=$3,failure_reason=NULL,status='pending_payment',payment_status='unpaid',checkout_state='ready',updated_at=NOW() WHERE id=$1 AND payment_status='unpaid' AND payment_session_id IS NULL AND checkout_state='creating' RETURNING id", [checkoutResult.orderId, session.id, session.url]);
      if (!saved.rowCount) { await expireCheckoutSession(session.id).catch(() => {}); return res.status(409).json({ message: 'Checkout state changed. Please retry.', orderId: checkoutResult.orderId, requestId: req.requestId }); }
    } catch (persistErr) { await expireCheckoutSession(session.id).catch(() => {}); await query("UPDATE orders SET checkout_state='idle',failure_reason=$2 WHERE id=$1 AND payment_session_id IS NULL", [checkoutResult.orderId, String(persistErr.message || 'Checkout persistence error').slice(0, 500)]).catch(() => {}); throw persistErr; }
    res.status(201).json({ ok: true, orderId: checkoutResult.orderId, url: session.url, expiresAt: checkoutResult.expiresAt, requestId: req.requestId });
  } catch (e) { next(e); }
});

app.get('/api/orders/:id', rateLimited('order-status', 30, 60), async (req, res, next) => {
  try {
    const id = String(req.params.id || ''), access = String(req.query.access || '');
    if (!/^[0-9a-f-]{36}$/i.test(id) || access.length < 32 || access.length > 128) return res.status(404).json({ message: 'Order not found.', requestId: req.requestId });
    const r = await query(`SELECT id,currency,subtotal_cents,discount_cents,total_cents,status,payment_status,fulfillment_status,tracking_number,customer_phone,shipping_address,refunded_cents,created_at,updated_at,checkout_expires_at FROM orders WHERE id=$1 AND customer_access_token_hash=$2`, [id, hashToken(access)]);
    if (!r.rowCount) return res.status(404).json({ message: 'Order not found.', requestId: req.requestId });
    const items = (await query('SELECT product_name,unit_price_cents,quantity,line_total_cents FROM order_items WHERE order_id=$1 ORDER BY id', [id])).rows;
    res.json({ order: { ...r.rows[0], items }, requestId: req.requestId });
  } catch (e) { next(e); }
});

app.post('/api/ai/recommend', rateLimited('ai', AI_RATE_LIMIT, 60), requireObjectBody, async (req, res, next) => { try { const q = String(req.body.query || '').trim(); if (!q || q.length > 1000) return res.status(400).json({ message: 'Invalid query.', requestId: req.requestId }); const catalog=(await query("SELECT name,category,price_cents,currency,stock FROM products WHERE active=true ORDER BY id DESC LIMIT 30")).rows; res.json(await recommend(q,catalog)); } catch (e) { next(e); } });
app.get('/api/admin/products', async (req,res,next)=>{try{const q=typeof req.query.q==='string'?req.query.q.trim().slice(0,120):null;const r=await query(`SELECT id,slug,name,description,category,price_cents,compare_at_cents,currency,stock,active,metadata,created_at,updated_at FROM products WHERE ($1::text IS NULL OR name ILIKE '%'||$1||'%' OR slug ILIKE '%'||$1||'%') ORDER BY id DESC LIMIT 500`,[q]);res.json({items:r.rows,query:q})}catch(e){next(e)}});
app.post('/api/admin/products', requireRole('admin','superadmin'), requireObjectBody, async (req,res,next)=>{try{const name=String(req.body.name||'').trim(),category=String(req.body.category||'General').trim(),description=String(req.body.description||'').trim(),slug=String(req.body.slug||name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')).slice(0,160),currency=String(req.body.currency||process.env.STRIPE_CURRENCY||'USD').toUpperCase();const price=Number(req.body.priceCents),compare=req.body.compareAtCents===''||req.body.compareAtCents==null?null:Number(req.body.compareAtCents),stock=Number(req.body.stock);if(!name||!slug||!category||!/^[A-Z]{3}$/.test(currency)||currency!==String(process.env.STRIPE_CURRENCY||'USD').toUpperCase()||!Number.isSafeInteger(price)||price<0||compare!==null&&(!Number.isSafeInteger(compare)||compare<price)||!Number.isSafeInteger(stock)||stock<0)return res.status(400).json({message:'Invalid product data.',requestId:req.requestId});const metadata=typeof req.body.metadata==='object'&&req.body.metadata&&!Array.isArray(req.body.metadata)?JSON.stringify(req.body.metadata):'{}';const id=crypto.randomUUID();const r=await withTransaction(async c=>(await c.query(`INSERT INTO products(slug,name,description,category,price_cents,compare_at_cents,currency,stock,inventory_opening_stock,metadata) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$8,$9::jsonb) RETURNING id`,[slug,name,description,category,price,compare,currency,stock,metadata])).rows[0]);await auditAdmin(null,req,'product_create',{slug,name,stock,priceCents:price});res.status(201).json({ok:true,id:r.id})}catch(e){next(e)}});
app.patch('/api/admin/products/:id', requireRole('admin','superadmin'), requireObjectBody, async (req,res,next)=>{try{const id=Number(req.params.id);if(!Number.isSafeInteger(id)||id<1)return res.status(400).json({message:'Invalid product id.',requestId:req.requestId});const r=await query('SELECT * FROM products WHERE id=$1',[id]);if(!r.rowCount)return res.status(404).json({message:'Product not found.',requestId:req.requestId});const p=r.rows[0],name=req.body.name===undefined?p.name:String(req.body.name).trim(),price=req.body.priceCents===undefined?p.price_cents:Number(req.body.priceCents),compare=req.body.compareAtCents===undefined?p.compare_at_cents:(req.body.compareAtCents===''||req.body.compareAtCents==null?null:Number(req.body.compareAtCents)),active=req.body.active===undefined?p.active:Boolean(req.body.active);if(!name||!Number.isSafeInteger(price)||price<0||compare!==null&&(!Number.isSafeInteger(compare)||compare<price))return res.status(400).json({message:'Invalid product update.',requestId:req.requestId});const fields=['name=$1','price_cents=$2','compare_at_cents=$3','active=$4','updated_at=NOW()'],vals=[name,price,compare,active];if(req.body.description!==undefined){fields.push(`description=$${vals.length+1}`);vals.push(String(req.body.description).trim().slice(0,5000))}if(req.body.category!==undefined){fields.push(`category=$${vals.length+1}`);vals.push(String(req.body.category).trim().slice(0,60)||'General')}vals.push(id);await query(`UPDATE products SET ${fields.join(',')} WHERE id=$${vals.length}`,vals);await auditAdmin(null,req,'product_update',{productId:id,active,priceCents:price});res.json({ok:true})}catch(e){next(e)}});
app.post('/api/admin/products/:id/inventory', requireRole('admin','superadmin'), requireObjectBody, async (req,res,next)=>{try{const id=Number(req.params.id),delta=Number(req.body.delta);if(!Number.isSafeInteger(id)||id<1||!Number.isSafeInteger(delta)||delta===0)return res.status(400).json({message:'Invalid inventory adjustment.',requestId:req.requestId});const result=await withTransaction(async c=>{const p=(await c.query('SELECT id,stock FROM products WHERE id=$1 FOR UPDATE',[id])).rows[0];if(!p)return null;const next=Number(p.stock)+delta;if(next<0)return {error:'Adjustment would make stock negative.'};await c.query('UPDATE products SET stock=$1,updated_at=NOW() WHERE id=$2',[next,id]);await c.query("INSERT INTO inventory_ledger(product_id,quantity_delta,reason) VALUES($1,$2,'manual_adjustment')",[id,delta]);return {stock:next}});if(!result)return res.status(404).json({message:'Product not found.',requestId:req.requestId});if(result.error)return res.status(409).json({message:result.error,requestId:req.requestId});await auditAdmin(null,req,'inventory_adjust',{productId:id,delta,newStock:result.stock});res.json({ok:true,stock:result.stock})}catch(e){next(e)}});
app.get('/api/admin/orders/:id', async (req,res,next)=>{try{const r=await query(`SELECT id,customer_email,currency,subtotal_cents,discount_cents,total_cents,status,payment_status,payment_provider,payment_session_id,payment_intent_id,fulfillment_status,tracking_number,customer_phone,shipping_address,refunded_cents,failure_reason,created_at,updated_at,checkout_expires_at FROM orders WHERE id=$1`,[req.params.id]);if(!r.rowCount)return res.status(404).json({message:'Order not found.',requestId:req.requestId});const items=(await query('SELECT product_id,product_name,unit_price_cents,quantity,line_total_cents FROM order_items WHERE order_id=$1 ORDER BY id',[req.params.id])).rows;res.json({order:r.rows[0],items,requestId:req.requestId})}catch(e){next(e)}});
app.patch('/api/admin/orders/:id/fulfillment', requireRole('admin','superadmin'), requireObjectBody, async (req,res,next)=>{try{const status=String(req.body.status||''),tracking=String(req.body.trackingNumber||'').trim().slice(0,120);if(!['unfulfilled','processing','shipped','delivered','cancelled'].includes(status))return res.status(400).json({message:'Invalid fulfillment status.',requestId:req.requestId});const result=await withTransaction(async c=>{const o=(await c.query('SELECT id,payment_status,fulfillment_status FROM orders WHERE id=$1 FOR UPDATE',[req.params.id])).rows[0];if(!o)return null;if(['processing','shipped','delivered'].includes(status)&&o.payment_status!=='paid')return {error:'Only paid orders can enter fulfillment.'};if(status==='cancelled'&&o.payment_status==='paid')return {error:'Refund the paid order before cancelling fulfillment.'};const r=await c.query('UPDATE orders SET fulfillment_status=$1,tracking_number=$2,updated_at=NOW() WHERE id=$3 RETURNING id,fulfillment_status,tracking_number',[status,tracking,o.id]);await c.query('INSERT INTO admin_actions(id,session_id,action,ip,request_id,payload) VALUES($1,$2,$3,$4,$5,$6)',[crypto.randomUUID(),req.admin.id,'fulfillment_update',req.ip,req.requestId,JSON.stringify({orderId:o.id,status,tracking})]);return {order:r.rows[0]};});if(!result)return res.status(404).json({message:'Order not found.',requestId:req.requestId});if(result.error)return res.status(409).json({message:result.error,requestId:req.requestId});res.json({ok:true,order:result.order})}catch(e){next(e)}});
app.patch('/api/admin/supplier-leads/:id', requireRole('admin','superadmin'), requireObjectBody, async (req,res,next)=>{try{const status=String(req.body.status||'');if(!['new','contacted','qualified','rejected','converted'].includes(status))return res.status(400).json({message:'Invalid lead status.',requestId:req.requestId});const r=await query('UPDATE supplier_leads SET status=$1 WHERE id=$2 RETURNING id,status',[status,req.params.id]);if(!r.rowCount)return res.status(404).json({message:'Lead not found.',requestId:req.requestId});await auditAdmin(null,req,'supplier_lead_update',{leadId:req.params.id,status});res.json({ok:true,lead:r.rows[0]})}catch(e){next(e)}});

app.get('/api/admin/summary', async (req, res, next) => { try { const o = (await query("SELECT COUNT(*)::int orders,COALESCE(SUM(total_cents) FILTER (WHERE payment_status='paid'),0)::bigint revenue_cents,COUNT(*) FILTER (WHERE status='paid')::int paid_orders FROM orders")).rows[0], l = (await query('SELECT COUNT(*)::int count FROM supplier_leads')).rows[0]; res.json({ mode: COMMERCE_MODE, staging: stagingOnly, currency: configuredCurrency, orders: o.orders, paidOrders: o.paid_orders, revenueCents: String(o.revenue_cents), revenue: Number(o.revenue_cents) / 100, supplierLeads: l.count, securityEvents: Number((await query('SELECT COUNT(*)::int n FROM security_events')).rows[0].n), openIncidents: Number((await query('SELECT COUNT(*)::int n FROM security_incidents WHERE resolved=false')).rows[0].n), lockdown: await security.summary(), maintenance: Boolean(security.state.maintenance) }); } catch (e) { next(e); } });
app.get('/api/admin/orders', async (req, res, next) => { try { const limit = Math.min(Math.max(Number(req.query.limit) || 50, 1), 100); const rawCursor = req.query.cursor; const cursor = decodeCursor(rawCursor); if (rawCursor && !cursor) return res.status(400).json({ message: 'Invalid cursor.', requestId: req.requestId }); const params = [limit + 1]; const where = []; if (cursor?.createdAt) { params.push(cursor.createdAt, cursor.id); where.push(`(created_at,id) < ($${params.length-1}::timestamptz,$${params.length})`); } else if (cursor?.id) { params.push(cursor.id); where.push(`id < $${params.length}`); } const r = await query(`SELECT id,customer_email,currency,total_cents,status,payment_status,payment_provider,fulfillment_status,tracking_number,created_at,updated_at FROM orders ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY created_at DESC,id DESC LIMIT $1`, params); const hasMore = r.rows.length > limit; const items = hasMore ? r.rows.slice(0, limit) : r.rows; res.json({ items, limit, nextCursor: hasMore ? encodeCursor({ id: items.at(-1).id, createdAt: items.at(-1).created_at }) : null }); } catch (e) { next(e); } });
app.get('/api/admin/security', async (req, res, next) => { try { const events = (await query('SELECT id,event_type,ip,request_id,payload,created_at FROM security_events ORDER BY created_at DESC LIMIT 100')).rows; res.json({ lockdown: await security.summary(), maintenance, recentEvents: events.map(e => ({ id: e.id, type: e.event_type, ip: e.ip, requestId: e.request_id, meta: e.payload, at: e.created_at })), incidents: await security.getIncidents(50) }); } catch (e) { next(e); } });
app.get('/api/admin/supplier-leads', async (req, res, next) => { try { const r = await query('SELECT id,name,country,type,contact_window,note,status,created_at FROM supplier_leads ORDER BY created_at DESC,id DESC LIMIT 200'); res.json({ items: r.rows }); } catch (e) { next(e); } });
app.post('/api/admin/security/lockdown', requireRole('superadmin'), requireObjectBody, async (req, res, next) => { try { await security.lockDown(String(req.body.reason || 'Emergency lockdown').slice(0, 240), 'admin'); res.json({ ok: true, lockdown: await security.summary(), requestId: req.requestId }); } catch (e) { next(e); } });
app.post('/api/admin/security/unlock', requireRole('superadmin'), requireObjectBody, async (req, res, next) => { try { if (security.state.lockedDown && req.body.confirm !== true) return res.status(400).json({ message: 'Explicit unlock confirmation required.', requestId: req.requestId }); await security.unlock(String(req.body.reason || 'Admin restored site').slice(0, 240)); res.json({ ok: true, lockdown: await security.summary(), requestId: req.requestId }); } catch (e) { next(e); } });
app.post('/api/admin/maintenance', requireRole('superadmin'), requireObjectBody, async (req, res, next) => { try { maintenance = req.body.enabled === true; security.state.maintenance = maintenance; await query('UPDATE security_state SET maintenance=$1,updated_at=NOW() WHERE id=1', [maintenance]); await query('INSERT INTO admin_actions(id,session_id,action,ip,request_id,payload) VALUES($1,$2,$3,$4,$5,$6)', [crypto.randomUUID(), req.admin.id, 'maintenance_change', req.ip, req.requestId, JSON.stringify({ enabled: maintenance })]); res.json({ ok: true, maintenance, requestId: req.requestId }); } catch (e) { next(e); } });
app.post('/api/admin/security/auto-lock', requireRole('superadmin'), requireObjectBody, async (req, res, next) => { try { security.state.autoLock = req.body.enabled === true; await query('UPDATE security_state SET auto_lock=$1,updated_at=NOW() WHERE id=1', [security.state.autoLock]); await security.addEvent('auto_lock_changed', { enabled: security.state.autoLock, ip: req.ip, requestId: req.requestId }); res.json({ ok: true, enabled: security.state.autoLock, requestId: req.requestId }); } catch (e) { next(e); } });
app.post('/api/admin/self-heal', requireRole('superadmin'), async (req, res, next) => { try { const actions = []; const a = await query('DELETE FROM admin_sessions WHERE expires_at<NOW() OR revoked_at IS NOT NULL OR last_seen_at<NOW()-($1::int*INTERVAL \'1 minute\')', [ADMIN_IDLE_MIN]); actions.push({ name: 'Expired admin sessions', changed: a.rowCount > 0, detail: `Removed ${a.rowCount} expired/revoked/idle session(s).` }); const b = await query('DELETE FROM ip_bans WHERE expires_at<=NOW()'); actions.push({ name: 'Expired IP bans', changed: b.rowCount > 0, detail: `Removed ${b.rowCount} expired ban(s).` }); const released = await releaseExpiredReservations(); actions.push({ name: 'Inventory reservations', changed: released > 0, detail: `Released ${released} expired reservation(s).` }); const rl = await query("DELETE FROM rate_limit_buckets WHERE window_start < NOW()-INTERVAL '2 hours'"); actions.push({ name: 'Rate-limit buckets', changed: rl.rowCount > 0, detail: `Removed ${rl.rowCount} old bucket(s).` }); res.json({ ok: true, actions, requestId: req.requestId }); } catch (e) { next(e); } });
app.get('/api/admin/inventory/reconciliation', async (req,res,next)=>{try{const mismatches=await reconcileInventory(10000);res.json({ok:mismatches.length===0,count:mismatches.length,mismatches,requestId:req.requestId})}catch(e){next(e)}});
app.post('/api/admin/diagnostics', async (req, res) => { let db = false; try { await ping(); db = true; } catch {} const mismatches = db ? await reconcileInventory(100) : []; const checks = [
  { name: 'Node', ok: Number(process.versions.node.split('.')[0]) >= 22, detail: process.version },
  { name: 'Admin secret', ok: ADMIN_TOKEN.length >= 48, detail: 'Bootstrap secret policy' }, { name: 'Database', ok: db, detail: db ? 'PostgreSQL reachable' : 'Database unavailable' },
  { name: 'Payments', ok: paymentReady(), detail: paymentReady() ? 'Stripe configured' : 'Stripe configuration incomplete' }, { name: 'Auto lockdown', ok: security.state.autoLock, detail: security.state.autoLock ? 'Armed' : 'Disarmed' },
  { name: 'IP abuse protection', ok: security.state.ipBan.enabled, detail: security.state.ipBan.enabled ? 'Enabled' : 'Disabled' }, { name: 'Shared rate limiting', ok: db, detail: 'PostgreSQL-backed fixed-window buckets' },
  { name: 'Admin session store', ok: db, detail: 'PostgreSQL-backed rotating sessions' }, { name: 'Database TLS', ok: process.env.NODE_ENV !== 'production' || process.env.DATABASE_SSL === 'true', detail: process.env.DATABASE_SSL === 'true' ? 'Enabled' : 'Not required in development' },
  { name: 'Inventory reconciliation', ok: db && mismatches.length === 0, detail: db ? (mismatches.length === 0 ? 'No stock mismatch detected' : 'Inventory mismatch detected; manual review required') : 'Database unavailable' }
]; res.json({ ok: checks.every(x => x.ok), checks, warnings: checks.filter(x => !x.ok), requestId: req.requestId }); });

app.use(express.static(STATIC_DIR, { dotfiles: 'deny', etag: false, maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0 }));
app.use((req, res) => res.status(404).json({ message: 'Not found', requestId: req.requestId }));
app.use(async (err, req, res, next) => { try { await security.addEvent('server_error', { path: req.path, method: req.method, requestId: req.requestId, ip: req.ip }); } catch (auditErr) { console.error('[SECURITY AUDIT ERROR]', auditErr); } console.error('[HTTP ERROR]', err); res.status(err.statusCode || 500).json({ message: err.publicMessage || (err.statusCode && err.statusCode < 500 ? err.message : 'Internal server error'), requestId: req.requestId }); });

async function reconcileInventory(limit=10000) {
  const r = await query(`SELECT p.id,p.stock,p.inventory_opening_stock,COALESCE(SUM(l.quantity_delta),0)::bigint ledger_delta
    FROM products p LEFT JOIN inventory_ledger l ON l.product_id=p.id
    GROUP BY p.id,p.stock,p.inventory_opening_stock
    HAVING p.stock <> p.inventory_opening_stock + COALESCE(SUM(l.quantity_delta),0)
    ORDER BY p.id LIMIT $1`, [limit]);
  return r.rows;
}
async function recoverStaleCheckoutStates() {
  const r = await query("UPDATE orders SET checkout_state='idle',failure_reason=COALESCE(failure_reason,'Checkout creation worker recovered a stale attempt'),updated_at=NOW() WHERE checkout_state='creating' AND payment_session_id IS NULL AND last_checkout_attempt_at < NOW()-INTERVAL '5 minutes' AND payment_status='unpaid' RETURNING id");
  return r.rowCount;
}
async function releaseExpiredReservations(batchSize = 250) {
  let released = 0;
  while (true) {
    const count = await withTransaction(async c => {
      const rows = (await c.query("SELECT id,order_id,product_id,quantity FROM inventory_reservations WHERE status='reserved' AND expires_at < NOW() ORDER BY expires_at FOR UPDATE SKIP LOCKED LIMIT $1", [batchSize])).rows;
      if (!rows.length) return 0;
      const groups = new Map(); for (const r of rows) { const key = `${r.order_id}:${r.product_id}`; const x = groups.get(key) || { order_id: r.order_id, product_id: r.product_id, quantity: 0 }; x.quantity += Number(r.quantity); groups.set(key, x); }
      for (const it of groups.values()) { await c.query('UPDATE products SET stock=stock+$1 WHERE id=$2', [it.quantity, it.product_id]); await c.query("INSERT INTO inventory_ledger(product_id,order_id,quantity_delta,reason) VALUES($1,$2,$3,'release')", [it.product_id, it.order_id, it.quantity]); await c.query("UPDATE inventory_reservations SET status='released',released_at=NOW() WHERE order_id=$1 AND product_id=$2 AND status='reserved'", [it.order_id, it.product_id]); await c.query("UPDATE order_items SET stock_reserved=false WHERE order_id=$1 AND product_id=$2 AND stock_reserved=true", [it.order_id, it.product_id]); }
      const orderIds = [...new Set(rows.map(r => r.order_id))]; for (const id of orderIds) await c.query("UPDATE orders SET status='payment_expired',checkout_expires_at=NULL WHERE id=$1 AND payment_status='unpaid' AND NOT EXISTS (SELECT 1 FROM inventory_reservations WHERE order_id=$1 AND status='reserved')", [id]);
      return rows.length;
    });
    released += count; if (count < batchSize) break;
  }
  return released;
}
async function refreshOperationalState() { try { const r = await query('SELECT locked_down,locked_at,reason,maintenance,auto_lock FROM security_state WHERE id=1'); if (r.rowCount) { const x = r.rows[0]; security.state.lockedDown = Boolean(x.locked_down); security.state.lockedAt = x.locked_at?.toISOString?.() ?? x.locked_at ?? null; security.state.reason = x.reason || null; maintenance = Boolean(x.maintenance); security.state.autoLock = Boolean(x.auto_lock); } } catch (e) { console.error('[STATE REFRESH]', e.message); } }
async function bootstrap() { await security.init(); await refreshOperationalState(); await recoverStaleCheckoutStates(); await releaseExpiredReservations(); setInterval(() => refreshOperationalState().catch(() => {}), 5000).unref(); setInterval(() => query('DELETE FROM admin_sessions WHERE expires_at<NOW() OR revoked_at IS NOT NULL OR last_seen_at<NOW()-($1::int*INTERVAL \'1 minute\')', [ADMIN_IDLE_MIN]).catch(() => {}), 300000).unref(); setInterval(() => query('DELETE FROM ip_bans WHERE expires_at<=NOW()').catch(() => {}), 300000).unref(); setInterval(() => query("DELETE FROM rate_limit_buckets WHERE window_start < NOW()-INTERVAL '2 hours'").catch(() => {}), 300000).unref(); setInterval(() => recoverStaleCheckoutStates().catch(() => {}), 30000).unref(); setInterval(() => releaseExpiredReservations().catch(e => console.error('[RESERVATION CLEANUP]', e.message)), 30000).unref(); }
process.on('uncaughtException', async e => { console.error('[FATAL]', e); try { await security.lockDown('Automatic lockdown: fatal exception', 'runtime'); } finally { process.exit(1); } });
process.on('unhandledRejection', async e => { console.error('[FATAL]', e); try { await security.lockDown('Automatic lockdown: unhandled rejection', 'runtime'); } finally { process.exit(1); } });
let server; bootstrap().then(() => { server = app.listen(PORT, () => console.log(`NEO backend listening on ${PORT}`)); }).catch(e => { console.error('[BOOT FAILURE]', e); process.exit(1); });
async function shutdown() { if (server) await new Promise(resolve => server.close(resolve)); await closeDb().catch(() => {}); process.exit(0); }
process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
