const controlRe=/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/;
const emailRe=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const issue=(path,message)=>({path,message,code:'custom'});
function result(success,data,issues=[]){return success?{success:true,data}:{success:false,error:{issues}}}
function strictKeys(obj,allowed){return Object.keys(obj).every(k=>allowed.includes(k));}
export const checkoutSchema={safeParse(input){
  const issues=[]; if(!input||typeof input!=='object'||Array.isArray(input)) return result(false,null,[issue([],'Expected an object')]);
  const allowed=['customerEmail','items','idempotencyKey']; if(!strictKeys(input,allowed)) for(const k of Object.keys(input)) if(!allowed.includes(k)) issues.push(issue([k],'Unrecognized key')); 
  const email=String(input.customerEmail??'').trim(); if(email.length>320||!emailRe.test(email)) issues.push(issue(['customerEmail'],'Invalid email'));
  if(!Array.isArray(input.items)||input.items.length<1||input.items.length>50) issues.push(issue(['items'],'Items must contain 1..50 entries'));
  const items=[]; if(Array.isArray(input.items)) for(let i=0;i<input.items.length;i++){const x=input.items[i]; if(!x||typeof x!=='object'||Array.isArray(x)){issues.push(issue(['items',i],'Invalid item'));continue;} if(!strictKeys(x,['productId','quantity'])) for(const k of Object.keys(x)) if(!['productId','quantity'].includes(k)) issues.push(issue(['items',i,k],'Unrecognized key')); const id=Number(x.productId),q=Number(x.quantity); if(!Number.isSafeInteger(id)||id<=0) issues.push(issue(['items',i,'productId'],'Invalid product id')); if(!Number.isInteger(q)||q<1||q>20) issues.push(issue(['items',i,'quantity'],'Quantity must be 1..20')); items.push({productId:id,quantity:q}); }
  let idem; if(input.idempotencyKey!==undefined){idem=String(input.idempotencyKey).trim(); if(idem.length<16||idem.length>128||!/^[A-Za-z0-9._:-]+$/.test(idem)) issues.push(issue(['idempotencyKey'],'Invalid idempotency key'));}
  return issues.length?result(false,null,issues):result(true,{customerEmail:email.toLowerCase(),items,idempotencyKey:idem});
}};
function safeText(value,max){const v=String(value??'').trim();return v.length<=max&&!controlRe.test(v)?v:null;}
export const leadSchema={safeParse(input){
  const issues=[]; if(!input||typeof input!=='object'||Array.isArray(input)) return result(false,null,[issue([],'Expected an object')]); const allowed=['name','phone','country','type','contactWindow','note']; for(const k of Object.keys(input)) if(!allowed.includes(k)) issues.push(issue([k],'Unrecognized key'));
  const name=safeText(input.name,100),phone=safeText(input.phone,30),country=safeText(input.country,60),type=safeText(input.type,60),contactWindow=safeText(input.contactWindow??'',40),note=safeText(input.note??'',1000);
  if(!name)issues.push(issue(['name'],'Invalid name')); if(!phone||phone.length<3)issues.push(issue(['phone'],'Invalid phone')); if(!country)issues.push(issue(['country'],'Invalid country')); if(!type)issues.push(issue(['type'],'Invalid type')); if(contactWindow===null)issues.push(issue(['contactWindow'],'Invalid contact window')); if(note===null)issues.push(issue(['note'],'Invalid note'));
  return issues.length?result(false,null,issues):result(true,{name,phone,country,type,contactWindow,note});
}};
export function parseBody(schema,body){const r=schema.safeParse(body);return r.success?{ok:true,data:r.data}:{ok:false,issues:r.error.issues};}
export function requireObjectBody(req,res,next){if(!req.is('application/json')||!req.body||typeof req.body!=='object'||Array.isArray(req.body))return res.status(400).json({message:'JSON object body required.',requestId:req.requestId});next();}
